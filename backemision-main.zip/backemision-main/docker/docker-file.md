# Dockerfile

# Crear una imagen desde un Dockerfile
'''
docker build -t image-processcpe-ms .
'''

### Para crear el contenedor
'''
docker run -d --name processcpe-ms image-processcpe-ms
'''

### Para verl logs dentro de un contenedor
'''
docker logs processcpe-ms
'''

### Para conectarse al contenedor
'''
docker exec -it processcpe-ms sh 
'''

### Para crear una red Brigde
'''
docker network create red-ms -d bridge 
'''

### Para conectar contenedores a una red
'''
docker network connect red-ms mongo-server
'''

### Para saber que contenedores están en una red
'''
docker network inspect red-ms
'''

### Crear el contenedor con variables de entorno
'''
docker run -d --name processcpe-ms -e MONGO_HOST=mongo-server -e RABBIT_HOST=rabbitmq:5672 --network red-ms image-processcpe-ms
'''