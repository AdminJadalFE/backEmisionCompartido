# Docker Compose

### Para ejecutar un docker-compose.yaml
'''
docker compose up -d
'''
### Para ejecutar un docker-compose.yaml y recrear imagenes
'''
docker compose up -d --build
'''

### Para revisar el estado de los contenedores
'''
docker compose ps
'''

### Para eliminar todo lo creado
'''
docker compose down
'''