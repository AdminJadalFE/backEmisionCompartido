import express, { Application, Request, Response } from "express";
import { EnvironmentsHelper } from "./helpers/environments.helper";
import axios from "axios"; 
import jwt_decode from "jwt-decode";  
 

interface Route {
  origin: string;
  target: string;
  method: any;
  middlewares: any[];
}

type Routes = Route[];

class App {
  expressApp: Application;

  routes: Routes = [ 
    {
      origin: "/api/cpe/getresumencpe",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/getresumencpe`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/tipocpe",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/tipocpe`,
      method: "get",
      middlewares: [],
    },
    {
      origin: "/api/cpe/tipodoc",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/tipodoc`,
      method: "get",
      middlewares: [],
    },
    {
      origin: "/api/cpe/estadocpe",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/estadocpe`,
      method: "get",
      middlewares: [],
    },
    {
      origin: "/api/cpe/sedes",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/sedes`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/getdataresumen",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/getdataresumen`,
      method: "post",
      middlewares: [],
    },

    {
      origin: "/api/cpe/gettotalemision",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/gettotalemision`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/gettotalestados",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/gettotalestados`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/getestadotipocpe",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/getestadotipocpe`,
      method: "post",
      middlewares: [],
    }, 
    {
      origin: "/api/cpe/getcpe",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/getcpe`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/searchcpe",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/searchcpe`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/sendemail",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/sendemail`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/getresumen",
      target: `${EnvironmentsHelper.pathMSCpe}/cpe/getresumen`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/cpe/registercpe",
      target: `${EnvironmentsHelper.pathMSOrder}/cpe/registercpe`,
      method: "post",
      middlewares: [this.authentication],
    },
    {
      origin: "/api/auth/register",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/register`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/auth/login",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/login`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/auth/get-new-access-token",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/get-new-access-token`,
      method: "post",
      middlewares: [],
    },  
    {
      origin: "/api/auth/user/register",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/user/register`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/auth/user/login",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/user/login`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/auth/user/get-new-access-token",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/user/get-new-access-token`,
      method: "post",
      middlewares: [],
    },
    {
      origin: "/api/auth/useremisor/delete",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/useremisor/delete`,
      method: "delete",
      middlewares: [],
    },
    {
      origin: "/api/auth/useremisor/getemisorbyuser",
      target: `${EnvironmentsHelper.pathMSAuth}/auth/useremisor/getemisorbyuser`,
      method: "post",
      middlewares: [],
    },
  ];

  constructor() {
    this.functionCustom = this.functionCustom.bind(this);
    this.expressApp = express();
    this.habilitarCORS();
    this.middlewares();
    this.mountRoutes();
  }

  middlewares() {
    this.expressApp.use(express.json());
    this.expressApp.use(express.urlencoded({ extended: false }));
  }

  mountRoutes() {
    this.routes.forEach((route) => {
      let myRouteFun;
      switch (route.method.toLowerCase()) {
        case "get":
          this.expressApp.get(
            route.origin,
            ...route.middlewares,
            this.functionCustom(route)
          );
          break;
        case "post":
          myRouteFun = this.expressApp.post(
            route.origin,
            ...route.middlewares,
            this.functionCustom(route)
          );
          break;
        case "put":
          myRouteFun = this.expressApp.put(
            route.origin,
            ...route.middlewares,
            this.functionCustom(route)
          );
          break;
          case "delete":
            myRouteFun = this.expressApp.delete(
              route.origin,
              ...route.middlewares,
              this.functionCustom(route)
            );
            break;
      }
    });

    this.expressApp.get("/", (req: Request, res: Response) => {
      res.send("Jadal System API!");
    });
  }

  functionCustom(route: Route) {
    return async (req: Request, res: Response) => {
      try {
        const queryString = this.getParameters("querystring", req);

        const rqAxios: any = {
          method: route.method,
          url: route.target,
          responseType: "json",
          maxContentLength: 100000000,
          maxBodyLength: 1000000000
        };

        if (queryString) {
          rqAxios.url += `?${queryString}`;
        }
 
        if ((route.method === "post" || route.method === "put") && Object.keys(req.body).length > 0) {
  
          rqAxios.data = req.body;
          
          if (res.locals.rucEmisor) {
            rqAxios.data.rucEmisor = res.locals.rucEmisor;
          }
        }
  
        const result = await axios(rqAxios);
        res.json(result.data);
      } catch (err) {
        console.log("An error ocurred");
        console.log({err});
        res.json({ err });
      }
    };
  }

  getParameters(typeParameters: string, req: Request): string {
    let params = "";

    switch (typeParameters) {
      case "querystring":
        for (let key in Object.keys(req.query)) {
          params += params
            ? `&${key}=${req.query[key]}`
            : `${key}=${req.query[key]}`;
        }
        break;
    }

    return params;
  }


    async authentication(req: Request, res: Response, next: any) {
      const authorization = req.headers["authorization"];

      if (!authorization) {
        return res.status(401).json({
          message: "Access token is missing",
        });
      }

      const elementsHeaderAuthorization = authorization.split(" ");

      if (elementsHeaderAuthorization.length !== 2) {
        return res.status(401).json({
          message: "Access token is missing",
        });
      }

      const [_, accessToken] = elementsHeaderAuthorization;

      const rqAxios: any = {
        method: "post",
        url: `${EnvironmentsHelper.pathMSAuth}/auth/validate-access-token`,
        responseType: "json",
        data: { accessToken },
      };
      const result = await axios(rqAxios);
      const response = result.data;

      if (!response.isValid) {
        return res.status(401).json({
          message: "not authorized: Validate Access token or Emisor data",
        });
      }

      const payload: any = jwt_decode(accessToken);
      res.locals.rucEmisor = payload.rucEmisor;

      return next();
    }


    habilitarCORS(){
      this.expressApp.use((req, res, next)=>{
          res.header("Access-Control-Allow-Origin", "*")
          res.header("Access-Control-Allow-Headers", "*")
          res.header("Access-Control-Allow-Methods", "GET, POST"); 
          next();
      });
    }
 
}

export default new App().expressApp; 
