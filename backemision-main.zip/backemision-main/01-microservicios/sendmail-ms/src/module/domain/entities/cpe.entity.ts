export type STATUS =  "ERROR MAIL" | "SUCCESS" | "NO MAIL";

export class MailBuilder {
    id: string;
    // fechaPublicacion: Date; 
    // fechaCpe: Date;
    // horaCpe: string;
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string;
    monedaCpe: string;
    rucReceptor: string;
    nombreReceptor: string;
    totalCpe: Number; 
    urlCpe: string;  
    urlPdf: string;  
    // estadoCpe: string;
    urlCdr : string;
    // fechaCdr : string;
    // horaCdr : string;
    codigoRespuesta : string;
    // descripcionRespuesta : string;
    estadoMail: STATUS;
    fechaMail: string; 
    idMail: string;  
  
    addid(id: string): MailBuilder{
        this.id = id;
        return this;
    } 
    // addfechaPublicacion(fechaPublicacion: Date): MailBuilder{
    //     this.fechaPublicacion = fechaPublicacion;
    //     return this;
    // }
    // addfechaCpe(fechaCpe: Date): MailBuilder{
    //     this.fechaCpe = fechaCpe;
    //     return this;
    // }
    // addhoraCpe(horaCpe: string): MailBuilder{
    //     this.horaCpe = horaCpe;
    //     return this;
    // }
    addrucEmisor(rucEmisor: string): MailBuilder{
        this.rucEmisor = rucEmisor;
        return this;
    }
    addnombreEmisor(nombreEmisor: string): MailBuilder{
        this.nombreEmisor = nombreEmisor;
        return this;
    }
    addtipoCpe(tipoCpe: string): MailBuilder{
        this.tipoCpe = tipoCpe;
        return this;
    } 
    addserieCpe(serieCpe: string): MailBuilder{
        this.serieCpe = serieCpe;
        return this;
    }
    addnumeroCpe(numeroCpe: string): MailBuilder{
        this.numeroCpe = numeroCpe;
        return this;
    }
    addmonedaCpe(monedaCpe: string): MailBuilder{
        this.monedaCpe = monedaCpe;
        return this;
    }
    addrucReceptor(rucReceptor: string): MailBuilder{
        this.rucReceptor = rucReceptor;
        return this;
    }
    addnombreReceptor(nombreReceptor: string): MailBuilder{
        this.nombreReceptor = nombreReceptor;
        return this;
    }
    addtotalCpe(totalCpe: Number): MailBuilder{
        this.totalCpe = totalCpe;
        return this;
    } 
    addurlCpe(urlCpe: string): MailBuilder{
        this.urlCpe = urlCpe;
        return this;
    }   
    addurlPdf(urlPdf: string): MailBuilder{
        this.urlPdf = urlPdf;
        return this;
    }   
    // addestadoCpe(estadoCpe: string): MailBuilder{
    //     this.estadoCpe = estadoCpe;
    //     return this;
    // }
    addurlCdr(urlCdr: string): MailBuilder{
        this.urlCdr = urlCdr;
        return this;
    } 
    // addfechaCdr(fechaCdr: string): MailBuilder{
    //     this.fechaCdr = fechaCdr;
    //     return this;
    // }
    // addhoraCdr(horaCdr: string): MailBuilder{
    //     this.horaCdr = horaCdr;
    //     return this;
    // }
    addcodigoRespuesta(codigoRespuesta: string): MailBuilder{
        this.codigoRespuesta = codigoRespuesta;
        return this;
    }
    // adddescripcionRespuesta(descripcionRespuesta: string): MailBuilder{
    //     this.descripcionRespuesta = descripcionRespuesta;
    //     return this;
    // } 
    addestadoMail(estadoMail: STATUS): MailBuilder{
        this.estadoMail = estadoMail;
        return this;
    }
    addfechaMail(fechaMail: string): MailBuilder{
        this.fechaMail = fechaMail;
        return this;
    }
    addidMail(idMail: string): MailBuilder{
        this.idMail = idMail;
        return this;
    } 
    build(): MailEntity {
        return new MailEntity(this);
    }
}

export class MailEntity {
    id: string;
    // fechaPublicacion: Date; 
    // fechaCpe: Date;
    // horaCpe: string;
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string;
    monedaCpe: string;
    rucReceptor: string;
    nombreReceptor: string;
    totalCpe: Number; 
    urlCpe : string; 
    urlPdf: string;  
    // estadoCpe: string;
    urlCdr : string;
    // fechaCdr : string;
    // horaCdr : string;
    codigoRespuesta : string;
    // descripcionRespuesta : string;
    estadoMail: STATUS;
    fechaMail: string; 
    idMail: string;  

    constructor(builder: MailBuilder){
        Object.assign(this, builder)
    }
}