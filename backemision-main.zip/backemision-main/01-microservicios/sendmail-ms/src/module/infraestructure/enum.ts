export enum QUEUE_NAME {
  ORCHESTATOR_EVENT = "ORCHESTATOR_EVENT",
  CPE_SEND_EVENT = "CPE_SEND_EVENT",
}

export enum TYPE_MESSAGE {
  SEND_EVENT = "SEND_EVENT",
  CPE_GETMAIL = "CPE_GETMAIL",
}

export enum EXCHANGE_NAME {
  FAILED_ERROR_EXCHANGE = "FAILED_ERROR_EXCHANGE",
  CPE_CONFIRMED_EXCHANGE = "CPE_CONFIRMED_EXCHANGE",
}

export enum EXCHANGE_TYPE {
  TOPIC = "topic",
  FANOUT = "fanout",
}

export enum ROUTING_KEY_ERROR {
  SEND_ERROR = "send.cpe_cancelled.error",
  MAIL_ERROR = "mail.cpe_cancelled.error",
}
