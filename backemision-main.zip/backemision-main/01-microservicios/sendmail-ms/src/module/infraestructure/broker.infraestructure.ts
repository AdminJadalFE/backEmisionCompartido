import RepositoryBroker from '../domain/repositories/cpe-broker-repository';
import BrokerBootstrap from '../../boostrap/broker.bootstrap'; 
import { MailBuilder } from '../domain/entities/cpe.entity';
import { EXCHANGE_NAME, QUEUE_NAME, TYPE_MESSAGE, EXCHANGE_TYPE } from "./enum";

import { CpeService } from './cpe.service';
const cpeService = new CpeService();

export default class BrokerInfraestructure implements RepositoryBroker{

    constructor(){}

    async send(message: any): Promise<void> {
        const nameExchange = EXCHANGE_NAME.CPE_CONFIRMED_EXCHANGE;
        const channel = BrokerBootstrap.getChannel();
        const messageAsString = JSON.stringify(message);
 
        await channel.assertExchange(nameExchange, EXCHANGE_TYPE.FANOUT, { durable: true });
        channel.publish(nameExchange, "", Buffer.from(messageAsString));
  
    }

    async sendError(message: any): Promise<void> {
        const channel = BrokerBootstrap.getChannel();
        const messageAsString = JSON.stringify(message);

        const exchangeName = EXCHANGE_NAME.FAILED_ERROR_EXCHANGE;
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.TOPIC, {durable: true});
        channel.publish(exchangeName, "mail.cpe_cancelled.error", Buffer.from(messageAsString));
    }


    async receive(): Promise<void> {
        const channel = BrokerBootstrap.getChannel(); 
        await this.receiveMessageCreated(channel, this.consumerCreated.bind(this));  
    }
   

    async receiveMessageCreated(channel: any,callback: (message: any, isError: boolean) => void) {
        const queueName = QUEUE_NAME.CPE_SEND_EVENT;
    
        await channel.assertQueue(queueName, { durable: true });
        // Recibir solo un mensaje a la vez
        channel.prefetch(1);
    
        channel.consume(queueName,(message: any) => {callback(message, false)},
          { noAck: false }
        );

      }
 

    async consumerCreated(message: any){ 

        const cpecontent = JSON.parse(message.content.toString()).payload; 

        // Send Email 
        const { messageId, fechaMail, status } = await cpeService.sendEmail(cpecontent);
 
        const cpeEntity = new MailBuilder()
                .addid(cpecontent.id)   
                .addrucEmisor(cpecontent.rucEmisor)
                .addnombreEmisor(cpecontent.nombreEmisor)
                .addtipoCpe(cpecontent.tipoCpe)
                .addserieCpe(cpecontent.serieCpe)
                .addnumeroCpe(cpecontent.numeroCpe) 
                .addmonedaCpe(cpecontent.monedaCpe)
                .addtotalCpe(cpecontent.totalCpe)
                .addrucReceptor(cpecontent.rucReceptor)
                .addnombreReceptor(cpecontent.nombreReceptor) 
                .addurlCpe(cpecontent.urlCpe)  
                .addurlPdf(cpecontent.urlPdf)  
                .addestadoMail(status)   
                .addcodigoRespuesta(cpecontent.codigoRespuesta) 
                .addfechaMail(fechaMail)
                .addidMail(messageId)
                .build(); 

        try {
            // await this.cpeInfraestructure.insert(cpeEntity);
               
            await this.send({type: TYPE_MESSAGE.SEND_EVENT,payload: cpeEntity,}); 

            const channel = BrokerBootstrap.getChannel();
            channel.ack(message); 
        } catch (error) {
            await this.sendError(cpeEntity);
        }
   
    }
 

}