import { CpeEntity, STATUS } from '../entities/cpe.entity';
export default interface Repository{
    insert(cpe: CpeEntity): Promise <CpeEntity>;
    update(id: string, estado: STATUS): Promise<string>;

}