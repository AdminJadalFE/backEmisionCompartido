import { ResumenEntity, STATUS } from '../entities/resumen.entity';
export default interface Repository{
    insert(cpe: ResumenEntity): Promise <ResumenEntity>;
    update(id: string, estado: STATUS): Promise<string>;

}