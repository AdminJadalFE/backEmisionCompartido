import RepositoryBroker from '../domain/repositories/cpe-broker-repository';
import BrokerBootstrap from '../../boostrap/broker.bootstrap'; 
import CpeInfraestructure from './cpe.infraestructure';
import ResumenInfraestructure from './resumen.infraestructure';
import { ResumenEntity, ResumenBuilder } from '../domain/entities/resumen.entity';
import { CpeBuilder, CpeEntity } from '../domain/entities/cpe.entity';
import { ROUTING_KEY_ERROR, EXCHANGE_NAME, EXCHANGE_TYPE, QUEUE_NAME, TYPE_MESSAGE } from "./enum";

import { CpeService } from './cpe.service';

const cpeService = new CpeService();

export default class BrokerInfraestructure implements RepositoryBroker{

    constructor(private cpeInfraestructure: CpeInfraestructure, private resumenInfraestructure: ResumenInfraestructure){}

    async send(message: any): Promise<void> {
        const channel = BrokerBootstrap.getChannel();
        const queueName = QUEUE_NAME.ORCHESTATOR_EVENT;
        await channel.assertQueue(queueName, {durable: true});
        await channel.sendToQueue(queueName, Buffer.from(JSON.stringify(message))); 
    }

    async sendError(message: any): Promise<void> {
        const channel = BrokerBootstrap.getChannel();
        const messageAsString = JSON.stringify(message); 
        const exchangeName =  EXCHANGE_NAME.FAILED_ERROR_EXCHANGE;
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.TOPIC, {durable: true});
        channel.publish(exchangeName, "process.cpe_cancelled.error", Buffer.from(messageAsString));
    }

    async receive(): Promise<void> {
        const channel = BrokerBootstrap.getChannel(); 
        const cpeCreated = this.receiveMessageCustom(channel, QUEUE_NAME.CPE_RECEIPT_EVENT, this.consumerCreated.bind(this));
        const cpeGetCdrCpe = this.receiveMessageCustom(channel, QUEUE_NAME.CPE_GETCDR_EVENT	, this.consumerGetCdrCpe.bind(this));
        const cpeGetCdrTicket = this.receiveMessageCustom(channel, QUEUE_NAME.RESUMEN_GETTICKET_EVENT	, this.consumerGetTicketResumen.bind(this));
        // const cpeGetCdrResumen = this.receiveMessageCustom(channel, QUEUE_NAME.RESUMEN_GETCDR_EVENT	, this.consumerGetCdrResumen.bind(this));

        const cpeError = this.receiveMessageError(channel, this.consumerError.bind(this));
        const cpeConfirm = this.receiveMessageConfirmCustom(EXCHANGE_NAME.CPE_CONFIRMED_EXCHANGE, channel,this.consumerConfirmedMailCpe.bind(this));
        const resumenConfirm = this.receiveMessageConfirmCustom(EXCHANGE_NAME.RESUMEN_CONFIRMED_EXCHANGE, channel,this.consumerConfirmedResumen.bind(this));
        await Promise.all([cpeCreated, cpeConfirm, cpeError, cpeGetCdrCpe, cpeGetCdrTicket, resumenConfirm]);
    }
  
    async receiveMessageCustom(channel: any, queueName: any,callback: (message: any, isError: boolean) => void) {
        await channel.assertQueue(queueName, { durable: true }); 
        channel.prefetch(1);
    
        channel.consume(
          queueName,
          (message: any) => {
            callback(message, false);
          },
          { noAck: false }
        );
      }
 
      async receiveMessageError(channel: any, callback: (message: any) => void) {
        const exchangeName = EXCHANGE_NAME.FAILED_ERROR_EXCHANGE;
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.TOPIC, { durable: true });
    
        const routingKeys = [
          ROUTING_KEY_ERROR.SEND_ERROR,
          ROUTING_KEY_ERROR.MAIL_ERROR,
        ];
        const assertQueue = await channel.assertQueue("", { exclusive: true });
    
        for (const routingKey of routingKeys) {
          channel.bindQueue(assertQueue.queue, exchangeName, routingKey);
        }
    
        channel.consume(assertQueue.queue, (message: any) => callback(message), {
          noAck: false,
        });
      }

      async receiveMessageConfirmCustom(
        exchangeName: any,
        channel: any,
        callback: (message: any) => void
      ) {
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.FANOUT, {
          durable: true,
        });
        channel.prefetch(1);
    
        const assertQueue = await channel.assertQueue("", { exclusive: true });
        channel.bindQueue(assertQueue.queue, exchangeName, "");
    
        channel.consume(assertQueue.queue, (message: any) => callback(message), {
          noAck: true,
        });
      }
 
      async consumerConfirmedMailCpe(message: any){ 
        const cpeEntity: Partial<CpeEntity> = JSON.parse(message.content.toString()).payload;    
        await this.cpeInfraestructure.updateMail(cpeEntity.id, cpeEntity); 
      }

      async consumerConfirmedResumen(message: any){ 
        console.log("consumerConfirmedResumen")
        const resumenEntity: Partial<ResumenEntity> = JSON.parse(message.content.toString()).payload;     
        console.log(resumenEntity)
        await this.resumenInfraestructure.updateCdr(resumenEntity.id, resumenEntity); 
        const cpes = await this.resumenInfraestructure.getBaja(resumenEntity.id)

        if (resumenEntity.codigoRespuesta === '0') {
          // Actualizar CPE solo si la Baja está aceptada.
          const JSONcpes = JSON.parse(cpes.cpes.replace(',]',']'))  
          for (let i = 0; i < JSONcpes.length; i++) {
            await this.cpeInfraestructure.updateCpeBaja(JSONcpes[i].id, "BAJA"); 
          } 
        }


      }
 
    async consumerError(message:any){
        const messageAsJSON = JSON.parse(message.content.toString());
        const estado = "ERROR";
        await this.cpeInfraestructure.update(messageAsJSON.payload.id, estado); 
    }
 
    async consumerGetCdrCpe(message: any){  
      const cpeEntity: Partial<CpeEntity> = JSON.parse(message.content.toString()).payload;   
      await this.cpeInfraestructure.updateCdr(cpeEntity.id, cpeEntity); 
      await this.send({ type: TYPE_MESSAGE.CPE_SEND,  payload:cpeEntity,});  
      const channel = BrokerBootstrap.getChannel();
      channel.ack(message);
    }
 
    async consumerGetTicketResumen(message: any){  
      console.log("consumerGetTicketResumen")
      const resumenEntity: Partial<ResumenEntity> = JSON.parse(message.content.toString()).payload;  
      console.log(resumenEntity)
      await this.resumenInfraestructure.updateTicket(resumenEntity.id, resumenEntity); 
      await this.send({ type: TYPE_MESSAGE.RESUMEN_GETCDR,  payload:resumenEntity,});   
      const channel = BrokerBootstrap.getChannel();
      channel.ack(message);
    }

    async consumerCreated(message: any){
      
        const {id, rucEmisor, fileCpe, filePdf, fechaPublicacion}  = JSON.parse(message.content.toString()).payload;
        // Create XML File
        const pathfileCpe = await cpeService.CreateFileFromBase64(id, 'xml', fileCpe); 
        const pathfilePdf = await cpeService.CreateFileFromBase64(id, 'pdf', filePdf); 
        // Read XML Content
        const cpe = await cpeService.ReadCpeFile(pathfileCpe); 
 
        let indTipoCpe:string 
        switch (cpe.tipoCpe) {
          case '01': 
          case '03':
          case '07': 
          case '08': 
          case '09': 
          case '20': 
          case '40':
              indTipoCpe = "CPE";
              break; 
          case 'RC': 
          case 'RR': 
          case 'RA':
              indTipoCpe = "RES";
              break; 
        }  

        // Validar si el CPE ya se encuentra registrado
        let cpeVal:string;
        switch (indTipoCpe) {
          case 'CPE':  
              cpeVal = await this.cpeInfraestructure.Validate(id);
              break; 
          case 'RES':  
              cpeVal = await this.resumenInfraestructure.Validate(id);             
              break; 
        }  

        let estadoEnt:string;
        if (parseInt(cpeVal) == 0) {
          estadoEnt = 'SUCCESS';
        } else {
          estadoEnt = 'DUPLICATE';
        }
    
        // Upload XML File
        const urlCpe = await cpeService.UploadS3File(id, '.xml', pathfileCpe); 
        const urlPdf = await cpeService.UploadS3File(id, '.pdf', pathfilePdf); 

        let objEntity:any;
        switch (indTipoCpe) {
          case 'CPE':  
              objEntity = new CpeBuilder() 
                      .addid(id)
                      .addfechaPublicacion(fechaPublicacion)
                      .addfechaCpe(cpe.fechaCpe)
                      .addhoraCpe(cpe.horaCpe)
                      .addrucEmisor(rucEmisor)
                      .addnombreEmisor(cpe.nombreEmisor)
                      .addtipoCpe(cpe.tipoCpe)
                      .addserieCpe(cpe.serieCpe)
                      .addnumeroCpe(cpe.numeroCpe)
                      .addmonedaCpe(cpe.monedaCpe) 
                      .addtipoDocReceptor(cpe.tipoDocReceptor)
                      .addrucReceptor(cpe.rucReceptor)
                      .addnombreReceptor(cpe.nombreReceptor)
                      .addtotalCpe(cpe.totalCpe) 
                      .addrucEmisor(rucEmisor) 
                      .addurlCpe(urlCpe)
                      .addurlPdf(urlPdf)
                      .addtipoCpeRef(cpe.tipoCpeRef)
                      .addserieCpeRef(cpe.serieCpeRef)
                      .addnumeroCpeRef(cpe.numeroCpeRef)
                      .addSucursal(cpe.Sucursal)
                      .addeMail(cpe.eMail)
                      .addestadoProccess(estadoEnt)
                      .build();   
              await this.cpeInfraestructure.insert(objEntity);     
              break; 
          case 'RES':   
              objEntity = new ResumenBuilder() 
                      .addid(id)
                      .addfechaPublicacion(fechaPublicacion)
                      .addfechaResumen(cpe.fechaResumen)
                      .addfechaReferencia(cpe.fechaReferencia)
                      .addrucEmisor(rucEmisor) 
                      .addtipoCpe(cpe.tipoCpe)
                      .addserieCpe(cpe.serieCpe)
                      .addnumeroCpe(cpe.numeroCpe) 
                      .addrucEmisor(rucEmisor) 
                      .addurlCpe(urlCpe)
                      .addurlPdf(urlPdf)
                      .addestadoProccess(estadoEnt)
                      .addcpes(cpe.cpes)
                      .build();  
              await this.resumenInfraestructure.insert(objEntity);             
              break; 
        } 
  
        if (parseInt(cpeVal) == 0) {
          objEntity.fileCpe = fileCpe; 
          switch (indTipoCpe) {
            case 'CPE':  
                await this.send({ type: TYPE_MESSAGE.CPE_PROCESS,  payload:objEntity,});     
                break; 
            case 'RES':  
                await this.send({ type: TYPE_MESSAGE.RESUMEN_PROCESS,  payload:objEntity,});                  
                break; 
          } 
        }else{
          // ACTUALIZAR DUPLICADOS
          switch (indTipoCpe) {
            case 'CPE':   
                await this.sendError({type: TYPE_MESSAGE.CPE_PROCESS,payload: objEntity,}) 
                break; 
            case 'RES':  
              await this.sendError({type: TYPE_MESSAGE.RESUMEN_PROCESS,payload: objEntity,})              
                break; 
          } 
        }
 
        const channel = BrokerBootstrap.getChannel();
        channel.ack(message);
 
    }
  
}