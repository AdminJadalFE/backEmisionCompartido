import mongoose from "mongoose";

class CpeModel {

    private cpeSchema: mongoose.Schema;

    constructor() {
        this.cpeSchema = new mongoose.Schema({
            id:{
                type: String,
                required: true
            }, 
            fechaPublicacion:{
                type: Date,
                required: true
            },
            fechaCpe:{
                type: Date,
                required: true
            },
            horaCpe:{
                type: String,
                required: true
            }, 
            rucEmisor:{
                type: String,
                required: true
            }, 
            nombreEmisor:{
                type: String,
                required: true
            }, 
            tipoCpe:{
                type: String,
                required: true
            },
            serieCpe:{
                type: String,
                required: true
            },
            numeroCpe:{
                type: String,
                required: true
            },
            monedaCpe:{
                type: String,
                required: true
            }, 
            rucReceptor:{
                type: String,
                required: true
            }, 
            tipoDocReceptor:{
                type: String,
                required: true
            }, 
            nombreReceptor:{
                type: String,
                required: true
            }, 
            totalCpe:{
                type: Number,
                required: true
            },
            urlCpe:{
                type: String,
                required: true
            },
            urlPdf:{
                type: String,
                required: true
            },
            estadoCpe:{
                type: String 
            },
            urlCdr:{
                type: String 
            },
            fechaCdr:{
                type: String 
            },
            horaCdr:{
                type: String 
            },
            codigoRespuesta:{
                type: String 
            },
            descripcionRespuesta:{
                type: String 
            },
            estadoMail:{
                type: String,
            },
            fechaMail:{
                type: String
            },
            eMail:{
                type: String
            },
            idMail:{
                type: String
            },
            tipoCpeRef:{
                type: String
            },
            serieCpeRef:{
                type: String
            },
            numeroCpeRef:{
                type: String
            },
            Sucursal:{
                type: String
            },
            estadoProccess:{
                type: String
            }

        });
    }

    get model(): mongoose.Model<mongoose.Document> {
        return mongoose.model<mongoose.Document>("Cpe", this.cpeSchema);
    }
 
}

export default new CpeModel().model;