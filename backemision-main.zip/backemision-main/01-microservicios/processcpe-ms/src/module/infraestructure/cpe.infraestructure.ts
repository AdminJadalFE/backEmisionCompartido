import { CpeEntity, STATUS } from '../domain/entities/cpe.entity';
import Repository from '../domain/repositories/cpe.repository';
import Model from './models/cpe.model';


export default class CpeInfraestructure implements Repository{
    
    async insert(cpe: CpeEntity): Promise<CpeEntity> { 
        await Model.create(cpe);
        return cpe; 
    }
    async update(id: string, estado: STATUS): Promise<string> {
        await Model.findOneAndUpdate({id}, {estado});
        return estado;
    } 
    async updateCdr(id: string, cpe: Partial<CpeEntity>): Promise<string> {
        const {estadoCpe, urlCdr, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta} = cpe;
        await Model.findOneAndUpdate({id}, {estadoCpe, urlCdr, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta});
        return id;
    } 
    async updateCpeBaja(id: string, estadoCpe: string): Promise<string> {
        await Model.findOneAndUpdate({id}, {estadoCpe});
        return id;
    } 

    async updateMail(id: string, cpe: Partial<CpeEntity>): Promise<string> {
        const {fechaMail, idMail, estadoMail} = cpe;
        await Model.findOneAndUpdate({id}, {fechaMail, idMail, estadoMail});
        return id; 
    }
    async Validate(id: string): Promise<string> {
        const cpe = await Model.find({id});
        return cpe.length.toString();
    } 
}