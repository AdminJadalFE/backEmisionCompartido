import fs from 'fs';
import AWS from 'aws-sdk';
import { DOMParser } from 'xmldom'; 
import extract from 'extract-zip';

const BUCKET_NAME = process.env.AWS_BUCKET_NAME;
const IAM_USER_KEY = process.env.AWS_ACCESS_KEY_ID;
const IAM_USER_SECRET = process.env.AWS_SECRET_ACCESS_KEY;

const s3bucket = new AWS.S3({
    accessKeyId: IAM_USER_KEY,
    secretAccessKey: IAM_USER_SECRET
  });

export class CpeService {


  async CreateFileFromBase64(id:string, ext:string, fileCpe: string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
 
        // Create XML from base64
        const pathName = 'assets/'; 
        const fileFullName = pathName + id + '.zip';  

        let buff = Buffer.from(fileCpe, 'base64');
        fs.writeFileSync(fileFullName, buff);

        await extract(fileFullName, { dir: '/app/' + pathName });

        // Eliminar Zip
        fs.unlinkSync(fileFullName);
 
        resolve(fileFullName.replace('zip',ext));

      } catch (err) {
        console.log(err)
        reject(err);
      }
    });
  }


  async ReadCpeFile(pathCpe: string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
  
        const parser = new DOMParser();
        const document = parser.parseFromString(fs.readFileSync(pathCpe, 'utf8'), 'text/xml'); 
        const nombreCpe = document.documentElement.nodeName;
 
        let cpe:any; 
        switch (nombreCpe) {
          case 'Invoice': 
          case 'CreditNote': 
          case 'DebitNote': 
          case 'DespatchAdvice': 
          case 'Retention': 
          case 'Perception': 
            cpe = await this.ReadCpe(nombreCpe, document);              
            break; 
          case 'SummaryDocuments': 
          case 'VoidedDocuments': 
            cpe = await this.ReadResumen(nombreCpe, document);              
            break; 
        } 
             
        resolve(cpe);

      } catch (err) {
        console.log(err)
        reject(err);
      }
    });
  }


  async ReadCpe(nombreCpe:string, document:Document): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {

        let serieNumero = document.getElementsByTagName("cbc:ID")[0].textContent;  
        const fechaCpe = document.getElementsByTagName("cbc:IssueDate")[0].textContent;
        const horaCpe = document.getElementsByTagName("cbc:IssueTime")[0] === undefined ?  "-" :  document.getElementsByTagName("cbc:IssueTime")[0].textContent;

        let tipoCpe:string;
        let monedaCpe:string;
        let totalCpe:string;
        let rucEmisor:string;
        let nombreEmisor:string;
        let tipoDocReceptor:string;
        let rucReceptor:string;
        let nombreReceptor:string;

        let tipoCpeRef:string = '';
        let serieCpeRef:string = '';
        let numeroCpeRef:string = '';

        let Sucursal:string = '';
        let eMail:string = '';
 
 
        switch (nombreCpe) {
          case 'Invoice':
            tipoCpe = document.getElementsByTagName("cbc:InvoiceTypeCode")[0].textContent;  
            totalCpe = document.getElementsByTagName("cac:LegalMonetaryTotal")[0].getElementsByTagName("cbc:PayableAmount")[0].textContent;
            break;
          case 'CreditNote':
            tipoCpe = document.getElementsByTagName("cbc:CreditNoteTypeCode")[0].textContent;  
            totalCpe = document.getElementsByTagName("cac:LegalMonetaryTotal")[0].getElementsByTagName("cbc:PayableAmount")[0].textContent;
            break; 
          case 'DebitNote':
            tipoCpe = "08";  
            totalCpe = document.getElementsByTagName("cac:RequestedMonetaryTotal")[0].getElementsByTagName("cbc:PayableAmount")[0].textContent;
             break; 
          case 'DespatchAdvice':
            tipoCpe = document.getElementsByTagName("cbc:DespatchAdviceTypeCode")[0].textContent;  
            monedaCpe = "-";
            totalCpe = "0.00";
            rucEmisor = document.getElementsByTagName("cac:DespatchSupplierParty")[0].getElementsByTagName("cbc:CustomerAssignedAccountID")[0].textContent; 
            nombreEmisor = document.getElementsByTagName("cac:DespatchSupplierParty")[0].getElementsByTagName("cac:PartyLegalEntity")[0].getElementsByTagName("cbc:RegistrationName")[0].textContent; 

            tipoDocReceptor = document.getElementsByTagName("cac:DeliveryCustomerParty")[0].getElementsByTagName("cbc:CustomerAssignedAccountID")[0].getAttribute("schemeID"); 
            rucReceptor = document.getElementsByTagName("cac:DeliveryCustomerParty")[0].getElementsByTagName("cbc:CustomerAssignedAccountID")[0].textContent; 
            nombreReceptor = document.getElementsByTagName("cac:DeliveryCustomerParty")[0].getElementsByTagName("cac:PartyLegalEntity")[0].getElementsByTagName("cbc:RegistrationName")[0].textContent;  
            break; 
          case 'Retention':
            tipoCpe = "20";          
            break;     
          case 'Perception':
            tipoCpe = "40";              
            break; 
        } 
 
        switch (nombreCpe) {
          case 'Invoice':
          case 'CreditNote':
          case 'DebitNote': 
            monedaCpe = document.getElementsByTagName("cbc:DocumentCurrencyCode")[0].textContent;
            rucEmisor = document.getElementsByTagName("cac:AccountingSupplierParty")[0].getElementsByTagName("cac:PartyIdentification")[0].getElementsByTagName("cbc:ID")[0].textContent; 
            nombreEmisor = document.getElementsByTagName("cac:AccountingSupplierParty")[0].getElementsByTagName("cac:PartyLegalEntity")[0].getElementsByTagName("cbc:RegistrationName")[0].textContent; 

            tipoDocReceptor = document.getElementsByTagName("cac:AccountingCustomerParty")[0].getElementsByTagName("cac:PartyIdentification")[0].getElementsByTagName("cbc:ID")[0].getAttribute("schemeID"); 
            rucReceptor = document.getElementsByTagName("cac:AccountingCustomerParty")[0].getElementsByTagName("cac:PartyIdentification")[0].getElementsByTagName("cbc:ID")[0].textContent; 
            nombreReceptor = document.getElementsByTagName("cac:AccountingCustomerParty")[0].getElementsByTagName("cac:PartyLegalEntity")[0].getElementsByTagName("cbc:RegistrationName")[0].textContent; 
            break;
          case 'Retention':
          case 'Perception': 
            serieNumero = document.getElementsByTagName("cbc:ID")[2].textContent;
            monedaCpe = document.getElementsByTagName("cbc:TotalInvoiceAmount")[0].getAttribute("currencyID"); 
            totalCpe = document.getElementsByTagName("cbc:TotalInvoiceAmount")[0].textContent; 
            rucEmisor = document.getElementsByTagName("cac:AgentParty")[0].getElementsByTagName("cac:PartyIdentification")[0].getElementsByTagName("cbc:ID")[0].textContent;  
            nombreEmisor = document.getElementsByTagName("cac:AgentParty")[0].getElementsByTagName("cac:PartyLegalEntity")[0].getElementsByTagName("cbc:RegistrationName")[0].textContent;  

            tipoDocReceptor = document.getElementsByTagName("cac:ReceiverParty")[0].getElementsByTagName("cac:PartyIdentification")[0].getElementsByTagName("cbc:ID")[0].getAttribute("schemeID"); 
            rucReceptor = document.getElementsByTagName("cac:ReceiverParty")[0].getElementsByTagName("cac:PartyIdentification")[0].getElementsByTagName("cbc:ID")[0].textContent;  
            nombreReceptor = document.getElementsByTagName("cac:ReceiverParty")[0].getElementsByTagName("cac:PartyLegalEntity")[0].getElementsByTagName("cbc:RegistrationName")[0].textContent;   
            break;  
        } 

        switch (nombreCpe) { 
          case 'CreditNote':
          case 'DebitNote': 
            serieCpeRef = document.getElementsByTagName("cac:BillingReference")[0].getElementsByTagName("cac:InvoiceDocumentReference")[0].getElementsByTagName("cbc:ID")[0].textContent.split('-')[0]; 
            numeroCpeRef = document.getElementsByTagName("cac:BillingReference")[0].getElementsByTagName("cac:InvoiceDocumentReference")[0].getElementsByTagName("cbc:ID")[0].textContent.split('-')[0]; 
            tipoCpeRef = document.getElementsByTagName("cac:BillingReference")[0].getElementsByTagName("cac:InvoiceDocumentReference")[0].getElementsByTagName("cbc:DocumentTypeCode")[0].textContent; 
            break;
        } 
  
        if (document.getElementsByTagName("ext:UBLExtension")[2].getElementsByTagName("jadal:AdditionalInformationCliente")[0].getElementsByTagName("jadal:Email")[0] === undefined) {
          eMail = "";
        }
        else{ 
          eMail = document.getElementsByTagName("ext:UBLExtension")[2].getElementsByTagName("jadal:AdditionalInformationCliente")[0].getElementsByTagName("jadal:Email")[0].textContent;
        }
  
        if (document.getElementsByTagName("ext:UBLExtension")[2].getElementsByTagName("jadal:AdditionalInformationCliente")[0].getElementsByTagName("jadal:Sucursal")[0] === undefined) {
            Sucursal = "-";
        }
        else{
            Sucursal = document.getElementsByTagName("ext:UBLExtension")[2].getElementsByTagName("jadal:AdditionalInformationCliente")[0].getElementsByTagName("jadal:Sucursal")[0].textContent;
        }
  
        const serieCpe = serieNumero.split('-')[0];
        const numeroCpe = serieNumero.split('-')[1];
 
        let cpe = {
          nombreCpe,
          serieCpe,
          numeroCpe,
          fechaCpe,
          horaCpe, 
          monedaCpe,
          tipoCpe,
          rucEmisor,
          nombreEmisor,
          tipoDocReceptor,
          rucReceptor,
          nombreReceptor,
          totalCpe, 
          serieCpeRef,
          numeroCpeRef,
          tipoCpeRef,
          eMail,
          Sucursal
        }
  
        resolve(cpe);
      } catch (err) {
        reject(err);
      }
    });
  }

  async ReadResumen(nombreCpe:string, document:Document): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
 
        let tipoCpe:string;  
    
        switch (nombreCpe) {
          case 'SummaryDocuments':
            tipoCpe = "RC";   
            break;
          case 'VoidedDocuments':
            tipoCpe = document.getElementsByTagName("cbc:ID")[0].textContent.split('-')[0];   
            break;  
        } 
 
        const rucEmisor = document.getElementsByTagName("cac:AccountingSupplierParty")[0].getElementsByTagName("cbc:CustomerAssignedAccountID")[0].textContent;  
        const serieNumero = document.getElementsByTagName("cbc:ID")[0].textContent;  
        const serieCpe = serieNumero.split('-')[1];
        const numeroCpe = serieNumero.split('-')[2];
        const fechaResumen = document.getElementsByTagName("cbc:IssueDate")[0].textContent;
        const fechaReferencia = document.getElementsByTagName("cbc:ReferenceDate")[0].textContent; 
 
        let cpes:string = "[";
        switch (nombreCpe) {
          case 'SummaryDocuments':
            var cpeResumen = document.getElementsByTagName("sac:SummaryDocumentsLine");
            for ( var i = 0; i < cpeResumen.length; i++) {
              const tipoCpeResumen = cpeResumen[i].getElementsByTagName("cbc:DocumentTypeCode")[0].textContent;
              const folioCpeResumen = cpeResumen[i].getElementsByTagName("cbc:ID")[0].textContent;
              cpes +=  `{"id":"${rucEmisor}-${tipoCpeResumen}-${folioCpeResumen}"},`;
            }
            break;
          case 'VoidedDocuments':
            
            var pElems = document.getElementsByTagName("sac:VoidedDocumentsLine");
            for ( var i = 0; i < pElems.length; i++) {
              const tipoCpeBaja = pElems[i].getElementsByTagName("cbc:DocumentTypeCode")[0].textContent;
              const serieCpeBaja = pElems[i].getElementsByTagName("sac:DocumentSerialID")[0].textContent;
              const DocumentNumberID = pElems[i].getElementsByTagName("sac:DocumentNumberID")[0].textContent;
              cpes +=  `{"id":"${rucEmisor}-${tipoCpeBaja}-${serieCpeBaja}-${DocumentNumberID}"},`;
            }
        } 
        cpes += "]"
    
        let cpe = {
          nombreCpe,
          serieCpe,
          numeroCpe, 
          tipoCpe,
          rucEmisor,
          fechaResumen,
          fechaReferencia,
          cpes
        } 
    
        resolve(cpe);
      } catch (err) {
        reject(err);
      }
    });
  }



  async UploadS3File(id:string, ext:string, pathfileCpe: string): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
 
        // Create File from base64
        const fileName = id + ext;  

        // Read File
        const fileContent = fs.createReadStream(pathfileCpe);
  
        // Upload file to S3
        const params = {
            Bucket: BUCKET_NAME,
            Key: fileName,
            Body: fileContent
        }

        s3bucket.upload(params, function(err:any, data:any) {
            fileContent.destroy();
            fs.unlinkSync(pathfileCpe)
            
            if (err) { 
                reject(err);
            } 
            resolve(data.Location);
          }); 
 
      } catch (err) {
        reject(err);
      }
    });
  }
  
}
