import { ResumenEntity, STATUS } from '../domain/entities/resumen.entity';
import Repository from '../domain/repositories/resumen.repository';
import Model from './models/resumen.model';


export default class CpeInfraestructure implements Repository{
    
    async insert(cpe: ResumenEntity): Promise<ResumenEntity> { 
        await Model.create(cpe);
        return cpe; 
    }
    
    async update(id: string, estado: STATUS): Promise<string> {
        await Model.findOneAndUpdate({id}, {estado});
        return estado;
    } 

    async updateTicket(id: string, cpe: Partial<ResumenEntity>): Promise<string> { 
 
        const {ticketResumen, estadoResumen, urlCdr, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta} = cpe;
        await Model.findOneAndUpdate({id}, {ticketResumen, estadoResumen, urlCdr, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta});
        return id;
    }  

    async updateCdr(id: string, cpe: Partial<ResumenEntity>): Promise<string> {
        const {estadoResumen, urlCdr, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta} = cpe;
        await Model.findOneAndUpdate({id}, {estadoResumen, urlCdr, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta});
        return id;
    }  

    async getBaja(id: string): Promise<any> {
        return await Model.findOne({id}); 
    } 
  
    async Validate(id: string): Promise<string> {
        const cpe = await Model.find({id});
        return cpe.length.toString();
    } 
}