import CpeApplication from '../module/application/cpe.aplication';

export default class TaskBootstrap {
    constructor(private cpeApplication:CpeApplication){}

    async listenMessage(){
        await this.cpeApplication.receiveMessage();
    }
}