import amqp from "amqplib";
import { Boostrap } from './boostrap';

let channel:amqp.Channel;

export default class BrokerBootstrap implements Boostrap {
    async initialize(): Promise<boolean | Error> {
        return new Promise( async (resolve, reject) => {
            const host = process.env.RABBITMQ_HOST || "localhost:5672";

            try {
                const connection = await amqp.connect(`amqp://${host}`);
                channel = await connection.createChannel();
                resolve(true);
                console.log("Connected to RabbitMQ");
            } catch (error) {
                reject(error);
            }
        })
    }

    static getChannel(){
        return channel
    }
    
}