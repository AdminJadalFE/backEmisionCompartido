export abstract class Boostrap{
    abstract initialize(): Promise<boolean | Error>;
}