import fs from 'fs';
import AWS from 'aws-sdk'; 
import axios from 'axios';    
import { DOMParser } from 'xmldom';
import extract from 'extract-zip';  


const BUCKET_NAME = process.env.AWS_BUCKET_NAME;
const IAM_USER_KEY = process.env.AWS_ACCESS_KEY_ID;
const IAM_USER_SECRET = process.env.AWS_SECRET_ACCESS_KEY;

const s3bucket = new AWS.S3({
    accessKeyId: IAM_USER_KEY,
    secretAccessKey: IAM_USER_SECRET
  });
 
const wsFactura = process.env.WSFACTURA;
const wsRetPer = process.env.WSRETPER;
const wsOse = process.env.WSOSE;

export class CpeService {
 
  async getUserSunat(rucEmisor:string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
        let rqAxios: any = {
          method: "post",
          url: `${process.env.PATH_MS_AUTH || "http://localhost:21000"}/auth/get-user-sunat`,
          responseType: "json",
          data: { rucEmisor },
        };
        let result = await axios(rqAxios);
        let response = result.data; 
        resolve(response);
      } catch (err) {
        reject(err);
      }
    });
  }
   

  async getStatus(emisor:any, tipoCpe:string, id:string, ticket:string): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
          
        let fileZipName = id + '.zip';
 
        let header = "<SOAP-ENV:Header><ns2:Security><ns2:UsernameToken><ns2:Username>" + emisor.rucEmisor + emisor.usuarioSunat + "</ns2:Username><ns2:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">" + emisor.claveSunat + "</ns2:Password></ns2:UsernameToken></ns2:Security></SOAP-ENV:Header>";
        let body = "<SOAP-ENV:Body><ns1:getStatus><ticket>" + ticket + "</ticket></ns1:getStatus></SOAP-ENV:Body>";
        let data = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://service.sunat.gob.pe\" xmlns:ns2=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">" +  header + body + "</SOAP-ENV:Envelope>";
      

        console.log("==================================================================================")
        console.log("Request SUNAT", data)
        console.log("==================================================================================")

        let Url:string;

        if (emisor.validador == '2') {
            // Validación por OSE
            Url = wsOse;  
        }else{
            // Validación por SUNAT
            switch (tipoCpe) {
              case 'RA':
              case 'RC': 
                Url = wsFactura;  
                break; 
              case 'RC': 
                Url = wsRetPer;
                break; 
            } 
        }

        console.log(Url)

        var config = {
          method: 'POST',
          url: Url,
          headers: { 
            'Content-Type': 'application/xml'
          },
          data : data,
          timeout: 30000,
        };
 
        axios(config)
        .then(function (response) {  
          resolve({status: true, cdr:response.data});
        })
        .catch(function (error) {   

          console.log("==================================================================================")
          console.log("Error SUNAT", error.response.status)
          console.log("==================================================================================")

          resolve({ status:false, cdr:error.response.data});
        }); 

      } catch (err) {

        console.log("==================================================================================")
        console.log("Error SUNAT", err)
        console.log("==================================================================================")

        reject({ status:false, cdr:err});
      }
    });
  }

  async createCdrFile(id:string, cdr:string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {

        let pathName = 'assets/'; 
        let fileFullName = pathName + 'R-' + id + '.zip'; 
          
        let parser = new DOMParser();
        let document = parser.parseFromString(cdr, 'text/xml');

        let bolTipoCdr:boolean;
  
        console.log("==================================================================================")
        console.log("cdr SUNAT", cdr)
        console.log("==================================================================================")

        // Evaluate Response Type 
        let cdrFile:any;
        let statusCode:any;
        if (document.getElementsByTagName("content")[0] === undefined) {
          bolTipoCdr = false;
          // Response Error  
          fs.writeFileSync(fileFullName.replace('.zip','.xml'), cdr);
        } else {
          bolTipoCdr = true;
          // Response OK 
          console.log("creando archivo OK")
          statusCode = document.getElementsByTagName("statusCode")[0].textContent; 
          console.log("statusCode", statusCode);
          cdrFile = document.getElementsByTagName("content")[0].textContent; 

          if (statusCode == '0' || statusCode == '99'){
            const buff = Buffer.from(cdrFile, 'base64');
            fs.writeFileSync(fileFullName, buff);
            await extract(fileFullName, { dir: '/app/' + pathName }) 
          }
          console.log("Cdr descomprimido correctamente");
        }

        const filePath = fileFullName.replace('.zip','.xml');
        resolve({bolTipoCdr, filePath, statusCode}); 

      } catch (err) { 
        reject(err);
      }
    });
  }

  async ReadCdrFile(bolTipoCdr:boolean, filePath: string, emisor:any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try { 
          
        let parser = new DOMParser();
        let document = parser.parseFromString(fs.readFileSync(filePath, 'utf8'), 'text/xml'); 
 
        let fechaCdr:any; 
        let horaCdr:any; 
        let codigoRespuesta:any; 
        let descripcionRespuesta:string='';  
        let estadoResumen:any;
        let ticketResumen:any='';
        if (bolTipoCdr === false) { 
          // Response Error
          fechaCdr = "-"; 
          horaCdr = "-"; 

          if (emisor.validador == '2') {
            codigoRespuesta = document.getElementsByTagName("faultstring")[0].textContent; 
            descripcionRespuesta = document.getElementsByTagName("message")[0].textContent; 
          } else {
              codigoRespuesta = document.getElementsByTagName("faultcode")[0].textContent.replace('soap-env:Client.','').replace('soap-env:Server.',''); 
              descripcionRespuesta = document.getElementsByTagName("faultstring")[0].textContent;   
          }

          estadoResumen = "RECHAZADO";
        } else { 
          // Response OK   
          fechaCdr = document.getElementsByTagName("cbc:ResponseDate")[0].textContent; 
          horaCdr = document.getElementsByTagName("cbc:ResponseTime")[0].textContent; 
          
          codigoRespuesta = document.getElementsByTagName("cac:DocumentResponse")[0]
                                          .getElementsByTagName("cac:Response")[0]
                                          .getElementsByTagName("cbc:ResponseCode")[0].textContent; 
          descripcionRespuesta = document.getElementsByTagName("cac:DocumentResponse")[0]
                                              .getElementsByTagName("cac:Response")[0]
                                              .getElementsByTagName("cbc:Description")[0].textContent;  
          estadoResumen = codigoRespuesta === "0" ? "ACEPTADO" : "RECHAZADO";
   
        }
   
        let cpe = {
          estadoResumen,
          fechaCdr, 
          horaCdr,
          codigoRespuesta,
          descripcionRespuesta, 
          ticketResumen,
        }

        console.log("cpe", cpe)
          
        resolve(cpe);

      } catch (err) {
        console.log(err)
        reject(err);
      }
    });
  }


  async UploadS3File(id: string, fileFullPath: string): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
 
        // Create XML from base64 
        let filePath = id + '.xml';  
    
        // Read XML
        let fileContent = fs.createReadStream(fileFullPath);
  
        // Upload file to S3
        let params = {
            Bucket: BUCKET_NAME,
            Key: 'R-' + filePath,
            Body: fileContent
        }

        s3bucket.upload(params, function(err:any, data:any) {
            fileContent.destroy();
            fs.unlinkSync(fileFullPath)
            
            if (err) { 
                reject(err);
            } 
            resolve(data.Location);
          }); 
 
      } catch (err) {
        reject(err);
      }
    });
  }
 
} 

