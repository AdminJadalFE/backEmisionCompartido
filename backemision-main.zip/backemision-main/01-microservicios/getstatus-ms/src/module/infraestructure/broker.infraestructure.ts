import RepositoryBroker from '../domain/repositories/cpe-broker-repository';
import BrokerBootstrap from '../../boostrap/broker.bootstrap'; 
import { CdrBuilder } from '../domain/entities/cpe.entity';
import { ROUTING_KEY_ERROR, EXCHANGE_NAME, EXCHANGE_TYPE, QUEUE_NAME, TYPE_MESSAGE } from "./enum";

import { CpeService } from './cpe.service';
let cpeService:CpeService;

export default class BrokerInfraestructure implements RepositoryBroker{

    constructor(){}

    async send(message: any): Promise<void> {  
        const nameExchange = EXCHANGE_NAME.RESUMEN_CONFIRMED_EXCHANGE;
        const channel = BrokerBootstrap.getChannel();
        const messageAsString = JSON.stringify(message);
 
        await channel.assertExchange(nameExchange, EXCHANGE_TYPE.FANOUT, { durable: true });
        channel.publish(nameExchange, "", Buffer.from(messageAsString));
    }

    async sendError(message: any): Promise<void> {
        const channel = BrokerBootstrap.getChannel();
        const messageAsString = JSON.stringify(message);

        const exchangeName = EXCHANGE_NAME.FAILED_ERROR_EXCHANGE;
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.TOPIC, {durable: true});
        channel.publish(exchangeName, "send.cpe_cancelled.error", Buffer.from(messageAsString));
    }

    async receive(): Promise<void> {
        const channel = BrokerBootstrap.getChannel();
        await this.receiveMessageCreated(channel, this.consumerCreated.bind(this));
    }
   
    async receiveMessageCreated(channel: any,callback: (message: any, isError: boolean) => void) {
        const queueName = QUEUE_NAME.RESUMEN_GETCDR_EVENT; 
        
        await channel.assertQueue(queueName, { durable: true });
        // Recibir solo un mensaje a la vez
        channel.prefetch(1);
        
        channel.consume(queueName,(message: any) => {callback(message, false)},
          { noAck: false }
        );
        
      }
     
    async consumerCreated(message: any){
 
        cpeService = new CpeService();
        let cpecontent = JSON.parse(message.content.toString()).payload;

        console.log("consumerCreated",cpecontent)

        // Get data from Emisor
        let emisor = await cpeService.getUserSunat(cpecontent.rucEmisor);
        // Send CPE to SUNAT
        let { cdr } = await cpeService.getStatus(emisor,cpecontent.tipoCpe, cpecontent.id, cpecontent.ticketResumen);
 
          console.log("==================================================================================")
          console.log("Response SUNAT", cdr)
          console.log("==================================================================================")
          // Create CDR File
          let {bolTipoCdr, filePath, statusCode} = await cpeService.createCdrFile(cpecontent.id, cdr); 

          if (statusCode != '0' && statusCode != '99') {
            console.log("No se obtuvo respuesta");
            return false;
          }          
          
          // Read CDR File
          let { estadoResumen, fechaCdr, horaCdr, codigoRespuesta, descripcionRespuesta } = await cpeService.ReadCdrFile(bolTipoCdr, filePath, emisor); 
 
          let urlCdr:string='';
          // Upload XML File
          urlCdr = await cpeService.UploadS3File(cpecontent.id, filePath);
 
          let CdrEntity = new CdrBuilder() 
                  .addid(cpecontent.id)
                  .addfechaPublicacion(cpecontent.fechaPublicacion) 
                  .addfechaResumen(cpecontent.fechaResumen) 
                  .addfechaReferencia(cpecontent.fechaReferencia) 
                  .addrucEmisor(cpecontent.rucEmisor)
                  .addtipoCpe(cpecontent.tipoCpe) 
                  .addserieCpe(cpecontent.serieCpe)
                  .addnumeroCpe(cpecontent.numeroCpe) 
                  .addurlCpe(cpecontent.urlCpe)
                  .addestadoResumen(estadoResumen)
                  .addurlCdr(urlCdr)
                  .addfechaCdr(fechaCdr)
                  .addhoraCdr(horaCdr)
                  .addcodigoRespuesta(codigoRespuesta)
                  .adddescripcionRespuesta(descripcionRespuesta)
                  .addticketResumen(cpecontent.ticketResumen)
                  .build(); 
  
          // await this.cpeInfraestructure.insert(CdrEntity); 
          await this.send({type: TYPE_MESSAGE.RESUMEN_GETCDR, payload: CdrEntity,});   
          const channel = BrokerBootstrap.getChannel(); 
          channel.ack(message);   
  
    }
 

}