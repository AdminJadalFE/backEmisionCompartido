import RepositoryBroker from '../domain/repositories/cpe-broker-repository';

export default class CpeApplication{ 
    private repositoryBroker: RepositoryBroker;

    constructor(repositoryBroker: RepositoryBroker){
        this.repositoryBroker = repositoryBroker
    } 
    
   async receiveMessage(): Promise<void>{
        await this.repositoryBroker.receive();
   }

   receiveMessages() {}
     
}