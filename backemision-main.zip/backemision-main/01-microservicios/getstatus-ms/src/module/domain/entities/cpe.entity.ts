export type STATUS =  "ERROR" | "PENDING" | "COMPLETED";

export class CdrBuilder {
    id: string; 
    fechaPublicacion: Date;
    fechaResumen: Date; 
    fechaReferencia: Date; 
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string; 
    rucReceptor: string; 
    urlCpe : string;   
    estadoResumen: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;
    ticketResumen: string; 

    addid(id: string): CdrBuilder{
        this.id = id;
        return this;
    }  
    addfechaPublicacion(fechaPublicacion: Date): CdrBuilder{
        this.fechaPublicacion = fechaPublicacion;
        return this;
    }
    addfechaResumen(fechaResumen: Date): CdrBuilder{
        this.fechaResumen = fechaResumen;
        return this;
    } 
    addfechaReferencia(fechaReferencia: Date): CdrBuilder{
        this.fechaReferencia = fechaReferencia;
        return this;
    }   
    addrucEmisor(rucEmisor: string): CdrBuilder{
        this.rucEmisor = rucEmisor;
        return this;
    }
    addnombreEmisor(nombreEmisor: string): CdrBuilder{
        this.nombreEmisor = nombreEmisor;
        return this;
    }
    addtipoCpe(tipoCpe: string): CdrBuilder{
        this.tipoCpe = tipoCpe;
        return this;
    } 
    addserieCpe(serieCpe: string): CdrBuilder{
        this.serieCpe = serieCpe;
        return this;
    }
    addnumeroCpe(numeroCpe: string): CdrBuilder{
        this.numeroCpe = numeroCpe;
        return this;
    } 
    addrucReceptor(rucReceptor: string): CdrBuilder{
        this.rucReceptor = rucReceptor;
        return this;
    } 
    addurlCpe(urlCpe: string): CdrBuilder{
        this.urlCpe = urlCpe;
        return this;
    }    
    addestadoResumen(estadoResumen: string): CdrBuilder{
        this.estadoResumen = estadoResumen;
        return this;
    }
    addurlCdr(urlCdr: string): CdrBuilder{
        this.urlCdr = urlCdr;
        return this;
    } 
    addfechaCdr(fechaCdr: string): CdrBuilder{
        this.fechaCdr = fechaCdr;
        return this;
    }
    addhoraCdr(horaCdr: string): CdrBuilder{
        this.horaCdr = horaCdr;
        return this;
    }
    addcodigoRespuesta(codigoRespuesta: string): CdrBuilder{
        this.codigoRespuesta = codigoRespuesta;
        return this;
    }
    adddescripcionRespuesta(descripcionRespuesta: string): CdrBuilder{
        this.descripcionRespuesta = descripcionRespuesta;
        return this;
    }
    addticketResumen(ticketResumen: string): CdrBuilder{
        this.ticketResumen = ticketResumen;
        return this;
    }
    build(): CdrEntity {
        return new CdrEntity(this);
    } 
}

export class CdrEntity {
    id: string; 
    fechaPublicacion: Date;
    fechaResumen: Date; 
    fechaReferencia: Date; 
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string; 
    rucReceptor: string; 
    urlCpe : string;  
    estadoCpe: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;
    ticketResumen: string; 
 
    constructor(builder: CdrBuilder){
        Object.assign(this, builder)
    }
}