import RepositoryQueue from "../application/repository-queue";
import BrokerBootstrap from "../../bootstrap/broker.bootstrap";
import {EXCHANGE_NAME,QUEUE_NAME,ROUTING_KEY_ERROR,TYPE_EXCHANGE,TYPE_MESSAGE,} from "./enums";

export default class OperationQueue implements RepositoryQueue {
  constructor() {}

  async sendMessage(queueName: string, message: any): Promise<void> {
    const channel = BrokerBootstrap.getChannel();
    await channel.assertQueue(queueName, { durable: true });
    await channel.sendToQueue(queueName, Buffer.from(JSON.stringify(message)));
  }

  async sendMessageError(routingKey: string, message: any): Promise<void> {
    const channel = BrokerBootstrap.getChannel();
    const messageAsString = JSON.stringify(message);

    const exchangeName = EXCHANGE_NAME.FAILED_ERROR_EXCHANGE;
    await channel.assertExchange(exchangeName, TYPE_EXCHANGE.TOPIC, {
      durable: true,
    });
    channel.publish(exchangeName, routingKey, Buffer.from(messageAsString));
  }

  async receiveMessage(): Promise<void> {
    const channel = BrokerBootstrap.getChannel();

    await this.receiveMessageOrchestator(
      channel,
      this.consumerOrchestator.bind(this)
    );
  }

  async receiveMessageOrchestator(
    channel: any,
    callback: (message: any) => void
  ) {
    const queueName = QUEUE_NAME.ORCHESTATOR_EVENT;

    await channel.assertQueue(queueName, { durable: true });

    channel.consume(
      queueName,
      (message: any) => {
        callback(message);
      },
      { noAck: false }
    );
  }

  getMessageToSent(messageAsJSON: any) {
    let newMessage;
    let queueName = "";
    let routingKey = "";

    console.log("orquestador", messageAsJSON)

    switch (messageAsJSON.type) {
      case TYPE_MESSAGE.CPE_RECEIPT:
        newMessage = {
          type: TYPE_MESSAGE.CPE_RECEIPT,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.CPE_RECEIPT_EVENT;
        break;
      case TYPE_MESSAGE.CPE_PROCESS:
        newMessage = {
          type: TYPE_MESSAGE.CPE_PROCESS,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.CPE_PROCESS_EVENT;
        break;
      case TYPE_MESSAGE.RESUMEN_PROCESS:
        newMessage = {
          type: TYPE_MESSAGE.RESUMEN_PROCESS,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.RESUMEN_PROCESS_EVENT;
        break;
      case TYPE_MESSAGE.CPE_SEND:
        newMessage = {
          type: TYPE_MESSAGE.CPE_SEND,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.CPE_SEND_EVENT;
        break;
      case TYPE_MESSAGE.CPE_GETCDR:
        newMessage = {
          type: TYPE_MESSAGE.CPE_GETCDR,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.CPE_GETCDR_EVENT;
        break;
        case TYPE_MESSAGE.RESUMEN_GETTICKET:
          newMessage = {
            type: TYPE_MESSAGE.RESUMEN_GETTICKET,
            payload: messageAsJSON.payload,
          };
          queueName = QUEUE_NAME.RESUMEN_GETTICKET_EVENT;
          break; 
      case TYPE_MESSAGE.RESUMEN_GETCDR:
        newMessage = {
          type: TYPE_MESSAGE.RESUMEN_GETCDR,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.RESUMEN_GETCDR_EVENT;
        break; 
      case TYPE_MESSAGE.CPE_MAIL:
        newMessage = {
          type: TYPE_MESSAGE.CPE_MAIL,
          payload: messageAsJSON.payload,
        };
        queueName = QUEUE_NAME.CPE_MAIL_EVENT;
        break;
      case TYPE_MESSAGE.PROCESS_ERROR:
        newMessage = {
          type: TYPE_MESSAGE.ERROR,
          payload: messageAsJSON.payload,
        };
        routingKey = ROUTING_KEY_ERROR.PROCESS;
        break;
      case TYPE_MESSAGE.SEND_ERROR:
        newMessage = {
          type: TYPE_MESSAGE.ERROR,
          payload: messageAsJSON.payload,
        };
        routingKey = ROUTING_KEY_ERROR.SEND;
        break;
      case TYPE_MESSAGE.MAIL_ERROR:
        newMessage = {
          type: TYPE_MESSAGE.ERROR,
          payload: messageAsJSON.payload,
        };
        routingKey = ROUTING_KEY_ERROR.MAIL;
        break;
    }

    return { newMessage, queueName, routingKey };
  }

  async consumerOrchestator(message: any) {

    const messageAsJSON = JSON.parse(message.content.toString());  
 
    const { newMessage, queueName, routingKey } = this.getMessageToSent(messageAsJSON);

    console.log(queueName);

    if (queueName) {
      this.sendMessage(queueName, newMessage);
    } else {
      this.sendMessageError(routingKey, newMessage);
    }

    const channel = BrokerBootstrap.getChannel();
    channel.ack(message);
  }
}
