export type STATUS =  "ERROR" | "PENDING" | "COMPLETED";

export class CdrBuilder {
    id: string;
    // fechaPublicacion: Date; 
    fechaCpe: Date;
    // horaCpe: string;
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string;
    monedaCpe: string;
    rucReceptor: string;
    // nombreReceptor: string;
    totalCpe: Number; 
    urlCpe : string; 
    urlPdf : string; 
    // estado: STATUS;
    estadoCpe: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;

    eMail: string; 

    addid(id: string): CdrBuilder{
        this.id = id;
        return this;
    } 
    // addfechaPublicacion(fechaPublicacion: Date): CdrBuilder{
    //     this.fechaPublicacion = fechaPublicacion;
    //     return this;
    // }
    addfechaCpe(fechaCpe: Date): CdrBuilder{
        this.fechaCpe = fechaCpe;
        return this;
    }
    // addhoraCpe(horaCpe: string): CdrBuilder{
    //     this.horaCpe = horaCpe;
    //     return this;
    // }
    addrucEmisor(rucEmisor: string): CdrBuilder{
        this.rucEmisor = rucEmisor;
        return this;
    }
    addnombreEmisor(nombreEmisor: string): CdrBuilder{
        this.nombreEmisor = nombreEmisor;
        return this;
    }
    addtipoCpe(tipoCpe: string): CdrBuilder{
        this.tipoCpe = tipoCpe;
        return this;
    } 
    addserieCpe(serieCpe: string): CdrBuilder{
        this.serieCpe = serieCpe;
        return this;
    }
    addnumeroCpe(numeroCpe: string): CdrBuilder{
        this.numeroCpe = numeroCpe;
        return this;
    }
    addmonedaCpe(monedaCpe: string): CdrBuilder{
        this.monedaCpe = monedaCpe;
        return this;
    }
    addrucReceptor(rucReceptor: string): CdrBuilder{
        this.rucReceptor = rucReceptor;
        return this;
    }
    // addnombreReceptor(nombreReceptor: string): CdrBuilder{
    //     this.nombreReceptor = nombreReceptor;
    //     return this;
    // }
    addtotalCpe(totalCpe: Number): CdrBuilder{
        this.totalCpe = totalCpe;
        return this;
    } 
    addurlCpe(urlCpe: string): CdrBuilder{
        this.urlCpe = urlCpe;
        return this;
    }  
    addurlPdf(urlPdf: string): CdrBuilder{
        this.urlPdf = urlPdf;
        return this;
    }      
    // addestado(estado: STATUS): CdrBuilder{
    //     this.estado = estado;
    //     return this;
    // }
    addestadoCpe(estadoCpe: string): CdrBuilder{
        this.estadoCpe = estadoCpe;
        return this;
    }
    addurlCdr(urlCdr: string): CdrBuilder{
        this.urlCdr = urlCdr;
        return this;
    } 
    addfechaCdr(fechaCdr: string): CdrBuilder{
        this.fechaCdr = fechaCdr;
        return this;
    }
    addhoraCdr(horaCdr: string): CdrBuilder{
        this.horaCdr = horaCdr;
        return this;
    }
    addcodigoRespuesta(codigoRespuesta: string): CdrBuilder{
        this.codigoRespuesta = codigoRespuesta;
        return this;
    }
    adddescripcionRespuesta(descripcionRespuesta: string): CdrBuilder{
        this.descripcionRespuesta = descripcionRespuesta;
        return this;
    }
    addeMail(eMail: string): CdrBuilder{
        this.eMail = eMail;
        return this;
    }
    build(): CdrEntity {
        return new CdrEntity(this);
    } 
}

export class CdrEntity {
    id: string;
    // fechaPublicacion: Date; 
    fechaCpe: Date;
    // horaCpe: string;
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string;
    monedaCpe: string;
    rucReceptor: string;
    // nombreReceptor: string;
    totalCpe: Number; 
    urlCpe : string; 
    urlPdf : string; 
    // estado: STATUS;
    estadoCpe: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;
    eMail: string; 
 
    constructor(builder: CdrBuilder){
        Object.assign(this, builder)
    }
}