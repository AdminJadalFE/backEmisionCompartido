import fs from 'fs';
import AWS from 'aws-sdk'; 
import axios from 'axios';    
import { DOMParser } from 'xmldom';
import extract from 'extract-zip';  
import {format} from "date-fns"; 
 

 
const BUCKET_NAME = process.env.AWS_BUCKET_NAME;
const IAM_USER_KEY = process.env.AWS_ACCESS_KEY_ID;
const IAM_USER_SECRET = process.env.AWS_SECRET_ACCESS_KEY;

const s3bucket = new AWS.S3({
    accessKeyId: IAM_USER_KEY,
    secretAccessKey: IAM_USER_SECRET
  });
 
const wsFactura = process.env.WSFACTURA;
const wsGuia = process.env.WSGUIA;
const wsRetPer = process.env.WSRETPER; 
const wsOse = process.env.WSOSE;

export class CpeService {
 
  async getUserSunat(rucEmisor:string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
        let rqAxios: any = {
          method: "post",
          url: `${process.env.PATH_MS_AUTH || "http://localhost:21000"}/auth/get-user-sunat`,
          responseType: "json",
          data: { rucEmisor },
        };
        let result = await axios(rqAxios);
        let response = result.data; 
        resolve(response);
      } catch (err) {
        reject(err);
      }
    });
  }
   

  async sendCpe(emisor:any, tipoCpe:string, id:string, cpeBase64:string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
          
        let fileZipName = id + '.zip';
 
        let header = "<SOAP-ENV:Header><ns2:Security><ns2:UsernameToken><ns2:Username>" + emisor.rucEmisor + emisor.usuarioSunat + "</ns2:Username><ns2:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">" + emisor.claveSunat + "</ns2:Password></ns2:UsernameToken></ns2:Security></SOAP-ENV:Header>";
        let body = "<SOAP-ENV:Body><ns1:sendBill><fileName>" + fileZipName + "</fileName><contentFile>" + cpeBase64 + "</contentFile></ns1:sendBill></SOAP-ENV:Body>";
        let data = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"http://service.sunat.gob.pe\" xmlns:ns2=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">" +  header + body + "</SOAP-ENV:Envelope>";
       
        let Url:string;
 
        if (emisor.validador == '2') {
            // Validación por OSE
            Url = wsOse;  
        }else{
            // Validación por SUNAT
            switch (tipoCpe) {
              case '01':
              case '03':
              case '07':
              case '08':
                Url = wsFactura;  
                break;
              case '09':
                Url = wsGuia;
                break; 
              case '20':
              case '40':
                Url = wsRetPer;
                break; 
            } 
        }

        console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - [sendCpe] Se realizará el envío al validador: " + Url)
 
        var config = {
          method: 'POST',
          url: Url,
          headers: { 
            'Content-Type': 'application/xml'
          },
          data : data,
          timeout: 30000,
        };
   
        axios(config)
        .then(function (response) {  
          resolve({status: true, cdr:response.data });
        })
        .catch(function (error) {   
          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - [sendCpe] ERROR Axios: " + id, error.response.status +  " - " + error.response.statusText )  
          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - [sendCpe] ERROR Axios: " + id, error.response.data )  
          resolve({ status:false, cdr:error.response.data});
        }); 
 

      } catch (err) {
        console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - [sendCpe] ERROR sendCpe: " + id, err.response.data) 
        reject({ status:false, cdr:err});
      }
    });
  }

  async createCdrFile(id:string, cdr:string): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {

        let pathName = 'assets/'; 
        let fileFullName = pathName + 'R-' + id + '.zip'; 
          
        let parser = new DOMParser();
        let document = parser.parseFromString(cdr, 'text/xml');

        let bolTipoCdr:boolean; 

        console.log("cdr", cdr)
 
        let cdrFile:any;
        if (document.getElementsByTagName("applicationResponse")[0] === undefined) {
          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - 3. [createCdrFile] Se obtuvo un error del validador en el envío del CPE: " + id)
          bolTipoCdr = false; 
          // Response Error  
          fs.writeFileSync(fileFullName.replace('.zip','.xml'), cdr);
        } else {
          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - 3. [createCdrFile] Se realizó correctamente el envío del CPE: " + id)
          bolTipoCdr = true;
          // Response OK 
          cdrFile = document.getElementsByTagName("applicationResponse")[0].textContent;
          const buff = Buffer.from(cdrFile, 'base64');
          fs.writeFileSync(fileFullName, buff);
          await extract(fileFullName, { dir: '/app/' + pathName }) 
        }

        const filePath = fileFullName.replace('.zip','.xml');
        resolve({bolTipoCdr, filePath}); 

      } catch (err) { 
        reject(err);
      }
    });
  }

  async ReadCdrFile(bolTipoCdr:boolean, filePath: string, emisor:any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try { 
          
        let parser = new DOMParser();
        let document = parser.parseFromString(fs.readFileSync(filePath, 'utf8'), 'text/xml'); 
 
        let fechaCdr:any; 
        let horaCdr:any; 
        let codigoRespuesta:any; 
        let descripcionRespuesta:any;  
        let estadoCpe:any; 

        if (bolTipoCdr === false) { 
          // Response Error
          fechaCdr = "-"; 
          horaCdr = "-"; 
          if (emisor.validador == '2') {
              codigoRespuesta = document.getElementsByTagName("faultstring")[0].textContent; 
              descripcionRespuesta = document.getElementsByTagName("message")[0].textContent; 
          } else {
              codigoRespuesta = document.getElementsByTagName("faultcode")[0].textContent.replace('soap-env:Client.','').replace('soap-env:Server.',''); 
              descripcionRespuesta = document.getElementsByTagName("faultstring")[0].textContent;   
          }         
          estadoCpe = "RECHAZADO";

          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - 4. [ReadCdrFile] Se procesó el archivo de error: " + filePath)
          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - 4. [ReadCdrFile]" + codigoRespuesta + " - " + descripcionRespuesta)
        } else { 
          // Response OK 
          fechaCdr = document.getElementsByTagName("cbc:ResponseDate")[0].textContent; 
          horaCdr = document.getElementsByTagName("cbc:ResponseTime")[0].textContent;  
          codigoRespuesta = document.getElementsByTagName("cac:DocumentResponse")[0]
                                          .getElementsByTagName("cac:Response")[0]
                                          .getElementsByTagName("cbc:ResponseCode")[0].textContent; 
          descripcionRespuesta = document.getElementsByTagName("cac:DocumentResponse")[0]
                                              .getElementsByTagName("cac:Response")[0]
                                              .getElementsByTagName("cbc:Description")[0].textContent;  
          estadoCpe = codigoRespuesta === "0" ? "ACEPTADO" : "RECHAZADO";

          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - 4. [ReadCdrFile] Se procesó el CDR: " + filePath)
          console.log(format(new Date(), "yyyy-MM-dd hh:mm:ss") + " - 4. [ReadCdrFile]" +  codigoRespuesta + " - " + descripcionRespuesta)
        }
   
        let cpe = {
          estadoCpe,
          fechaCdr, 
          horaCdr,
          codigoRespuesta,
          descripcionRespuesta, 
        }
          
        resolve(cpe);

      } catch (err) {
        console.log(err)
        reject(err);
      }
    });
  }


  async UploadS3File(id: string, fileFullPath: string): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
 
        // Create XML from base64 
        let filePath = id + '.xml';  
    
        // Read XML
        let fileContent = fs.createReadStream(fileFullPath);
  
        // Upload file to S3
        let params = {
            Bucket: BUCKET_NAME,
            Key: 'R-' + filePath,
            Body: fileContent
        }

        s3bucket.upload(params, function(err:any, data:any) {
            fileContent.destroy();
            fs.unlinkSync(fileFullPath)
            
            if (err) { 
                reject(err);
            } 
            resolve(data.Location);
          }); 
 
      } catch (err) {
        reject(err);
      }
    });
  }
   
} 

