import ServerBoostrap from "./boostrap/server.boostrap"; 
import BrokerBootstrap from './boostrap/broker.bootstrap';
import TaskBootstrap from './boostrap/task.bootstrap';
import CpeApplication from './module/application/cpe.aplication';
import BrokerInfraestructure from './module/infraestructure/broker.infraestructure';


const server = new ServerBoostrap(); 
const broker = new BrokerBootstrap(); 
const brokerInfraestructure = new BrokerInfraestructure();
const cpeApplication = new CpeApplication(brokerInfraestructure);
const task = new TaskBootstrap(cpeApplication);

async function start (){ 
    try {
        await server.initialize();
        await broker.initialize();
        await task.listenMessage();
    } catch (error) {
        console.log(error);
        process.exit(1);
    }
}

start();