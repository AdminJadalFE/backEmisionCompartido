import { ResumenEntity } from '../entities/resumen.entity';

export interface Tokens {
  accessToken: string;
  refreshToken: string;
}

export default interface ResumenRepository {
  getResumen(where: Object, select: Object): Promise<ResumenEntity>; 
}
