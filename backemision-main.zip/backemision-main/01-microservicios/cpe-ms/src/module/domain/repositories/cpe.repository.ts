import { CpeEntity } from '../entities/cpe.entity'; 

export interface Tokens {
  accessToken: string;
  refreshToken: string;
}

export default interface CpeRepository {
  getCpeById(id: string): Promise<CpeEntity>; 
  getCpe(where: Object, select: Object): Promise<CpeEntity>; 
  getSedes(where: Object): Promise<CpeEntity>; 
  getResumen(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<CpeEntity>; 

  getTotalEmision(where: Object): Promise<CpeEntity>; 
  getTotalEstados(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<CpeEntity>; 
  getEstadosTipoCpe(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<CpeEntity>; 
  
  getResumenCpe(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<CpeEntity>; 
  searchCpe(where: Object, select:object): Promise<CpeEntity>; 
}
