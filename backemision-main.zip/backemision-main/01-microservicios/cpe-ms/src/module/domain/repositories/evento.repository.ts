 
import { EventoEntity } from '../entities/evento.entity';
 
export default interface EventoRepository {
  
  registerEvent(evento: EventoEntity): Promise<boolean>;  
  
}
