
export type STATUS =  "ERROR" | "PENDING" | "COMPLETED";

export class ResumenBuilder {
    id: string;
    rucEmisor: string;
    tipoCpe: string; 
    serieCpe: string;
    numeroCpe: string; 
    fechaPublicacion: Date;
    fechaResumen: Date; 
    fechaReferencia: Date; 
    urlCpe : string;
    urlPdf : string;
    fileCpe : string; 
    ticketResumen: string;  
    estadoResumen: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;
    estadoProccess: string; 

    addid(id: string): ResumenBuilder{
        this.id = id;
        return this;
    }
    addrucEmisor(rucEmisor: string): ResumenBuilder{
        this.rucEmisor = rucEmisor;
        return this;
    }
    addtipoCpe(tipoCpe: string): ResumenBuilder{
        this.tipoCpe = tipoCpe;
        return this;
    }
    addserieCpe(serieCpe: string): ResumenBuilder{
        this.serieCpe = serieCpe;
        return this;
    }
    addnumeroCpe(numeroCpe: string): ResumenBuilder{
        this.numeroCpe = numeroCpe;
        return this;
    }
    addfechaPublicacion(fechaPublicacion: Date): ResumenBuilder{
        this.fechaPublicacion = fechaPublicacion;
        return this;
    }
    addfechaResumen(fechaResumen: Date): ResumenBuilder{
        this.fechaResumen = fechaResumen;
        return this;
    } 
    addfechaReferencia(fechaReferencia: Date): ResumenBuilder{
        this.fechaReferencia = fechaReferencia;
        return this;
    }   
    addurlCpe(urlCpe: string): ResumenBuilder{
        this.urlCpe = urlCpe;
        return this;
    }
    addurlPdf(urlPdf: string): ResumenBuilder{
        this.urlPdf = urlPdf;
        return this;
    }
    addfileCpe(fileCpe: string): ResumenBuilder{
        this.fileCpe = fileCpe;
        return this;
    }
    addticketResumen(ticketResumen: string): ResumenBuilder{
        this.ticketResumen = ticketResumen;
        return this;
    }
    addestadoResumen(estadoResumen: string): ResumenBuilder{
        this.estadoResumen = estadoResumen;
        return this;
    }
    addurlCdr(urlCdr: string): ResumenBuilder{
        this.urlCdr = urlCdr;
        return this;
    } 
    addfechaCdr(fechaCdr: string): ResumenBuilder{
        this.fechaCdr = fechaCdr;
        return this;
    }
    addhoraCdr(horaCdr: string): ResumenBuilder{
        this.horaCdr = horaCdr;
        return this;
    }
    addcodigoRespuesta(codigoRespuesta: string): ResumenBuilder{
        this.codigoRespuesta = codigoRespuesta;
        return this;
    }
    adddescripcionRespuesta(descripcionRespuesta: string): ResumenBuilder{
        this.descripcionRespuesta = descripcionRespuesta;
        return this;
    }
    addestadoProccess(estadoProccess: string): ResumenBuilder{
        this.estadoProccess = estadoProccess;
        return this;
    }
    build(): ResumenEntity {
        return new ResumenEntity(this);
    }
}

export class ResumenEntity {
    id: string;
    rucEmisor: string;
    tipoCpe: string; 
    serieCpe: string;
    numeroCpe: string; 
    fechaPublicacion: Date;
    fechaCpe: Date; 
    fechaReferencia: Date; 
    urlCpe : string;
    urlPdf : string;    
    fileCpe : string; 
    ticketResumen: string;  
    estadoResumen: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;
    estadoProccess: string; 
 
    constructor(builder: ResumenBuilder){
        Object.assign(this, builder)
    }
}