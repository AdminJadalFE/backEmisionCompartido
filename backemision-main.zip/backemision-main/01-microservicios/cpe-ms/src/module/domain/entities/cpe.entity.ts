
export type STATUS =  "ERROR" | "PENDING" | "COMPLETED";

export class CpeBuilder {
    id: string;
    fechaPublicacion: Date;
    fechaCpe: Date;
    horaCpe: string;
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string;
    monedaCpe: string;
    tipoDocReceptor: string;
    rucReceptor: string;
    nombreReceptor: string;
    totalCpe: Number; 
    urlCpe : string;
    urlPdf : string;
    fileCpe : string;
    estadoProccess: string; 

    estadoCpe: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;

    estadoMail: string; 
    eMail: string; 
    fechaMail: string; 
    idMail: string;  

    tipoCpeRef: string;
    serieCpeRef: string;
    numeroCpeRef: string;

    Sucursal: string;

    addid(id: string): CpeBuilder{
        this.id = id;
        return this;
    }
    addfechaPublicacion(fechaPublicacion: Date): CpeBuilder{
        this.fechaPublicacion = fechaPublicacion;
        return this;
    }
    addfechaCpe(fechaCpe: Date): CpeBuilder{
        this.fechaCpe = fechaCpe;
        return this;
    }
    addhoraCpe(horaCpe: string): CpeBuilder{
        this.horaCpe = horaCpe;
        return this;
    }
    addrucEmisor(rucEmisor: string): CpeBuilder{
        this.rucEmisor = rucEmisor;
        return this;
    }
    addnombreEmisor(nombreEmisor: string): CpeBuilder{
        this.nombreEmisor = nombreEmisor;
        return this;
    }
    addtipoCpe(tipoCpe: string): CpeBuilder{
        this.tipoCpe = tipoCpe;
        return this;
    } 
    addserieCpe(serieCpe: string): CpeBuilder{
        this.serieCpe = serieCpe;
        return this;
    }
    addnumeroCpe(numeroCpe: string): CpeBuilder{
        this.numeroCpe = numeroCpe;
        return this;
    }
    addmonedaCpe(monedaCpe: string): CpeBuilder{
        this.monedaCpe = monedaCpe;
        return this;
    }
    addtipoDocReceptor(tipoDocReceptor: string): CpeBuilder{
        this.tipoDocReceptor = tipoDocReceptor;
        return this;
    }
    
    addrucReceptor(rucReceptor: string): CpeBuilder{
        this.rucReceptor = rucReceptor;
        return this;
    }
    addnombreReceptor(nombreReceptor: string): CpeBuilder{
        this.nombreReceptor = nombreReceptor;
        return this;
    }
    addtotalCpe(totalCpe: Number): CpeBuilder{
        this.totalCpe = totalCpe;
        return this;
    } 
    addurlCpe(urlCpe: string): CpeBuilder{
        this.urlCpe = urlCpe;
        return this;
    }
    addurlPdf(urlPdf: string): CpeBuilder{
        this.urlPdf = urlPdf;
        return this;
    }
    addestadoProccess(estadoProccess: string): CpeBuilder{
        this.estadoProccess = estadoProccess;
        return this;
    }
    addestadoCpe(estadoCpe: string): CpeBuilder{
        this.estadoCpe = estadoCpe;
        return this;
    }
    addurlCdr(urlCdr: string): CpeBuilder{
        this.urlCdr = urlCdr;
        return this;
    } 
    addfechaCdr(fechaCdr: string): CpeBuilder{
        this.fechaCdr = fechaCdr;
        return this;
    }
    addhoraCdr(horaCdr: string): CpeBuilder{
        this.horaCdr = horaCdr;
        return this;
    }
    addcodigoRespuesta(codigoRespuesta: string): CpeBuilder{
        this.codigoRespuesta = codigoRespuesta;
        return this;
    }
    adddescripcionRespuesta(descripcionRespuesta: string): CpeBuilder{
        this.descripcionRespuesta = descripcionRespuesta;
        return this;
    } 

    addestadoMail(estadoMail: string): CpeBuilder{
        this.estadoMail = estadoMail;
        return this;
    } 
    addeMail(eMail: string): CpeBuilder{
        this.eMail = eMail;
        return this;
    }
    addfechaMail(fechaMail: string): CpeBuilder{
        this.fechaMail = fechaMail;
        return this;
    }
    addidMail(idMail: string): CpeBuilder{
        this.idMail = idMail;
        return this;
    } 

    addtipoCpeRef(tipoCpeRef: string): CpeBuilder{
        this.tipoCpeRef = tipoCpeRef;
        return this;
    } 
    addserieCpeRef(serieCpeRef: string): CpeBuilder{
        this.serieCpeRef = serieCpeRef;
        return this;
    } 
    addnumeroCpeRef(numeroCpeRef: string): CpeBuilder{
        this.numeroCpeRef = numeroCpeRef;
        return this;
    } 
    addSucursal(Sucursal: string): CpeBuilder{
        this.Sucursal = Sucursal;
        return this;
    } 
   
    build(): CpeEntity {
        return new CpeEntity(this);
    }
}

export class CpeEntity {
    id: string;
    fechaPublicacion: Date;
    fechaCpe: Date;
    horaCpe: string;
    rucEmisor: string;
    nombreEmisor: string;
    tipoCpe: string;
    serieCpe: string;
    numeroCpe: string;
    monedaCpe: string;
    tipoDocReceptor: string;
    rucReceptor: string;
    nombreReceptor: string;
    totalCpe: Number; 
    urlCpe : string;
    urlPdf : string;
    fileCpe : string;
    estadoProccess: string; 

    estadoCpe: string; 
    urlCdr : string;
    fechaCdr : string;
    horaCdr : string;
    codigoRespuesta : string;
    descripcionRespuesta : string;

    estadoMail: string; 
    eMail: string; 
    fechaMail: string; 
    idMail: string;  

    tipoCpeRef: string;
    serieCpeRef: string;
    numeroCpeRef: string;

    Sucursal: string;

    constructor(builder: CpeBuilder){
        Object.assign(this, builder)
    }
}