
export class EventoBuilder {
    tipo: string;
    id: string;
    referencia: string;
    estado: string;
    detalleEvento: string;
    fechaHora: string;

    addtipo(tipo: string): EventoBuilder{
        this.tipo = tipo;
        return this;
    }
    addid(id: string): EventoBuilder{
        this.id = id;
        return this;
    }
    addreferencia(referencia: string): EventoBuilder{
        this.referencia = referencia;
        return this;
    }
    addestado(estado: string): EventoBuilder{
        this.estado = estado;
        return this;
    }
    adddetalleEvento(detalleEvento: string): EventoBuilder{
        this.detalleEvento = detalleEvento;
        return this;
    }

    addfechaHora(fechaHora: string): EventoBuilder{
        this.fechaHora = fechaHora;
        return this;
    } 
   
    build(): EventoEntity {
        return new EventoEntity(this);
    }
}

export class EventoEntity {
    tipo: string;
    id: string;
    referencia: string;
    estado: string;
    detalleEvento: string;
    fechaHora: Date;
 
    constructor(builder: EventoBuilder){
        Object.assign(this, builder)
    }
}