 
import CpeRepository  from "../domain/repositories/cpe.repository"; 
import EventoRepository  from "../domain/repositories/evento.repository"; 
import { EventoBuilder } from '../domain/entities/evento.entity';
import {format} from "date-fns"; 
import { CpeService } from './cpe.service'; 
const cpeService = new CpeService();

export default class CpeApplication {
  private repositoryCpe: CpeRepository;
  private repositoryEvento: EventoRepository;

  constructor(repository: CpeRepository, repositoryEvento: EventoRepository) {
    this.repositoryCpe = repository;
    this.repositoryEvento = repositoryEvento
  }

 
  async getCpe(data: any): Promise<any> {  
    const { rucEmisor, fechaDesde, fechaHasta, estadoCpe, tipoCpe, serieCpe, numeroDesde, numeroHasta, rucReceptor, Sucursal } = data; 
    let queryString = `{"estadoProccess":"SUCCESS",`;
    queryString += `"rucEmisor":"${rucEmisor}"`;
    queryString += `,"fechaCpe": {
                                  "$gte": "${new Date(fechaDesde)}",
                                  "$lte": "${new Date(fechaHasta)}"
                                 }`;
    queryString += estadoCpe == '-' ? '' : `, "estadoCpe" : "${estadoCpe}"`;
    queryString += tipoCpe == '-' ? '' : `, "tipoCpe" : "${tipoCpe}"`;
    queryString += serieCpe == '-' ? '' : `, "serieCpe" : "${serieCpe}"`;
    queryString += Sucursal == '-' ? '' : `, "Sucursal" : "${Sucursal}"`;
    if (!(numeroDesde == '-' && numeroHasta == '-')) { 
      if (numeroHasta == '-') {
        queryString += numeroDesde == '-' ? '' : `, "numeroCpe" : "${numeroDesde}"`;   
      }else{
        queryString += `,"numeroCpe": {
          "$gte": "${numeroDesde}",
          "$lte": "${numeroHasta}"
         }`;
      }
    } 
    queryString += rucReceptor == '-' ? '' : `, "rucReceptor" : "${rucReceptor}"`;
    queryString += `}`;  
    let select = `{
                      "id" : true,
                      "tipoCpe" : true,
                      "serieCpe" : true,
                      "numeroCpe" : true, 
                      "nombreReceptor" : true,
                      "fechaCpe" : true,
                      "fechaPublicacion" : true,
                      "totalCpe" : true,
                      "monedaCpe" : true,
                      "estadoCpe" : true,
                      "Sucursal" : true,
                      "urlCpe" : true,
                      "urlPdf" : true,
                      "urlCdr" : true
                  }` 
    return await this.repositoryCpe.getCpe(JSON.parse(queryString),JSON.parse(select));    
  } 
  
  async getResumen(data: any): Promise<any> {   
    const { fechaDesde, fechaHasta, rucEmisor } = data;  
    return await this.repositoryCpe.getResumen(rucEmisor, fechaDesde, fechaHasta);      
  } 

  async getTotalEmision(data: any): Promise<any> {   
    console.log(data)
    const { fechaDesde, fechaHasta, rucEmisor } = data;  

 
    let queryString = `{"estadoProccess":"SUCCESS","rucEmisor":"${rucEmisor}"`; 
    queryString += `,"fechaCpe": {
                                  "$gte": "${new Date(fechaDesde)}",
                                  "$lte": "${new Date(fechaHasta)}"
                                 }`; 
    queryString += `}`;  
 

    const totalCpe = await this.repositoryCpe.getTotalEmision(JSON.parse(queryString)); 
     
     queryString = `{"estadoProccess":"SUCCESS", "estadoCpe" : "PENDIENTE","rucEmisor":"${rucEmisor}"`; 
    queryString += `,"fechaCpe": {
                                  "$gte": "${new Date(fechaDesde)}",
                                  "$lte": "${new Date(fechaHasta)}"
                                 }`; 
    queryString += `}`;  

    const pendienteCpe = await this.repositoryCpe.getTotalEmision(JSON.parse(queryString)); 

    const cpe = {
      totalCpe,
      pendienteCpe
    }
    
    return cpe;
  } 

  async getTotalEstados(data: any): Promise<any> {   
    const { fechaDesde, fechaHasta, rucEmisor } = data;  
    return await this.repositoryCpe.getTotalEstados(rucEmisor, fechaDesde, fechaHasta);      
  } 

  async getEstadosTipoCpe(data: any): Promise<any> {   
    const { fechaDesde, fechaHasta, rucEmisor } = data;  
    return await this.repositoryCpe.getEstadosTipoCpe(rucEmisor, fechaDesde, fechaHasta);      
  } 

  async sendEmail(data: any): Promise<any> {   

    try {
      
      const { id, emails } = data;  
      const cpe = await this.repositoryCpe.getCpeById(id);  
      
      const mails = emails.split(';') 
       
  
      mails.map(async (mail:any) => {
        
        let idEmail:string, fecha:string, estado:string, detalleEvento:string;
        if (cpe.codigoRespuesta === '0') {
          // Enviar Correo solo si el CPE está aceptado
          const { messageId, fechaMail, status } = await cpeService.sendEmail(cpe, mail);  
          fecha = fechaMail;
          estado = status;
          if (estado === 'ERROR') {
            detalleEvento = 'Ocurrió un error al envíar el correo: ' + messageId;  
          } else {
            detalleEvento = 'Se envió correctamente el correo a la bandeja : ' + mail + ', con identificador: ' + messageId;  
          } 
        } else {
          idEmail = '-';
          fecha = format(new Date(), "yyyy-MM-dd hh:mm:ss");
          estado = 'CANCELLED';
          detalleEvento = 'Envío de correo cancelado, CPE no se encuentra Aceptado';
        }
  
        const eventoEntity = new EventoBuilder()
        .addtipo('MAIL')
        .addid(cpe.id)    
        .addreferencia(mail)
        .addestado(estado)
        .adddetalleEvento(detalleEvento)
        .addfechaHora(fecha)
        .build(); 
  
        await this.repositoryEvento.registerEvent(eventoEntity);
        
      })
           
      return true;

    } catch (error) {
      return false;
    }

  } 

  async getSedes(data: any): Promise<any> {  
    const { rucEmisor } = data; 
    return await this.repositoryCpe.getSedes({rucEmisor});    
  } 

  async searchCpe(data:any): Promise<any> { 
    const { rucEmisor, tipoDocReceptor, rucReceptor, tipoCpe, serieCpe, numeroCpe, fechaCpe, totalCpe } = data;
    let select = `{
      "tipoCpe" : true,
      "serieCpe" : true,
      "numeroCpe" : true, 
      "nombreReceptor" : true,
      "fechaCpe" : true,
      "fechaPublicacion" : true,
      "totalCpe" : true,
      "monedaCpe" : true,
      "codigoRespuesta" : true,
      "descripcionRespuesta" : true,
      "Sucursal" : true,
      "urlCpe" : true,
      "urlPdf" : true,
      "urlCdr" : true
  }`
    return await this.repositoryCpe.searchCpe({rucEmisor, tipoDocReceptor, rucReceptor, tipoCpe, serieCpe, numeroCpe, fechaCpe, totalCpe},JSON.parse(select));  
  } 
  
  async getResumenCpe(data: any): Promise<any> {  
    const { fechaDesde, fechaHasta, rucEmisor } = data;  
    
    return await this.repositoryCpe.getResumenCpe(rucEmisor, fechaDesde, fechaHasta);    
  } 


}
 