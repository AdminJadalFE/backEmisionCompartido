import ResumenRepository from "../domain/repositories/resumen.repository"; 

export default class ResumenApplication {
  private repositoryResumen: ResumenRepository;

  constructor(repository: ResumenRepository) {
    this.repositoryResumen = repository;
  }

  async getResumen(data: any): Promise<any> { 
    
    const { rucEmisor, fechaDesde, fechaHasta, tipoCpe} = data;
 
    let queryString = `{"estadoProccess":"SUCCESS",`;
    queryString += `"rucEmisor":"${rucEmisor}"`;
    queryString += `,"fechaCpe": {
                                  "$gte": "${new Date(fechaDesde)}",
                                  "$lte": "${new Date(fechaHasta)}"
                                 }`;
    queryString += tipoCpe == '-' ? '' : `, "tipoCpe" : "${tipoCpe}"`;
    queryString += `}`; 
 
    let select = `{
                      "id" : true,
                      "tipoCpe" : true,
                      "serieCpe" : true,
                      "numeroCpe" : true,  
                      "fechaResumen" : true,
                      "fechaPublicacion" : true,
                      "estadoResumen" : true,
                      "urlCpe" : true,
                      "urlPdf" : true,
                      "urlCdr" : true
                  }`
    return await this.repositoryResumen.getResumen(JSON.parse(queryString),JSON.parse(select));   

  } 

   
}
 