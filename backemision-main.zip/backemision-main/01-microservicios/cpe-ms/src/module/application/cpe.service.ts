import AWS from 'aws-sdk'; 
import {format} from "date-fns"; 
import nodemailer from "nodemailer";

// const SES_CONFIG = {
//   apiVersion: "2010-12-01",
//   accessKeyId: process.env.AWS_ACCESS_KEY_ID,
//   secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
//   region: process.env.AWS_REGION
// };

const SES_CONFIG = {
  apiVersion: "2010-12-01",
  accessKeyId: process.env.AWS_ACCESS_KEY_ID || 'AKIAUZOHYURD43CHPK5T',
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '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',
  region: process.env.AWS_REGION || 'us-east-1'
};
   
const transporter = nodemailer.createTransport({
  SES: new AWS.SES(SES_CONFIG),
});
 
export class CpeService {
 
  async sendEmail(cpecontent:any, email:string): Promise<any> {   
    const fechaMail:any = format(new Date(), "yyyy-MM-dd hh:mm:ss");
    return new Promise(async (resolve, reject) => {
      try {
  
        let TipoCpeNombre:string;
        switch (cpecontent.tipoCpe) { 
          case '01':
            TipoCpeNombre = 'FACTURA ELECTRONICA';
            break;
          case '03': 
            TipoCpeNombre = 'BOLETA ELECTRONICA';
            break;
          case '07': 
            TipoCpeNombre = 'NOTA DE CREDITO ELECTRONICA';
            break;
          case '08': 
            TipoCpeNombre = 'NOTA DE DEBITO ELECTRONICA';
            break;
          case '09': 
            TipoCpeNombre = 'GUIA ELECTRONICA';
            break;
          case '20': 
            TipoCpeNombre = 'RETENCION ELECTRONICA';
            break;
          case '40': 
            TipoCpeNombre = 'PERCEPCION ELECTRONICA';
            break; 
        } 
        
          const mail = {
            from: process.env.EMAILFROM || 'noreply@jadalfe.pe',
            to: `${email}`,
            subject: `${cpecontent.nombreEmisor}: USTED HA RECIBIDO UN COMPROBANTE ELECTRONICO ${TipoCpeNombre} # ${cpecontent.serieCpe}-${cpecontent.numeroCpe} de ${cpecontent.fechaCpe}`,
            html:`<!DOCTYPE html>
            <html>
            <div>
                <table align="center" cellspacing="0" cellpadding="0" style="border:solid 2px #1F2C4C" width="650">
                    <tbody>
                            <tr>
                                <td style="text-align:justify;padding:20px">
                                    <p style="font:13px arial;margin:10px">Estimado cliente,</p>
                                    <p style="font:13px arial;margin:10px">Por el presente les informamos que la empresa<strong> ${cpecontent.nombreEmisor} </strong>emisora de comprobantes electronicos ha emitido el siguiente comprobante de pago electronico:</p>
                                    <p style="font:13px arial;margin:10px">
                                        <strong>
                                            Tipo de Documento: ${TipoCpeNombre}<br>
                                            Serie y número: ${cpecontent.serieCpe}-${cpecontent.numeroCpe}<br>
                                            RUC del emisor: ${cpecontent.rucEmisor}<br>
                                            RUC o DNI del cliente: ${cpecontent.rucReceptor}<br>
                                            Fecha de emision: ${cpecontent.fechaCpe}<br>
                                            Total: ${cpecontent.monedaCpe} ${cpecontent.totalCpe}
                                    </strong>
                                    </p>
                                    <p style="font:13px arial;margin:10px">Tambien pueden realizar la descarga de dicho comprobante de pago electronico a traves del siguiente <a href=${cpecontent.urlCpe}>Link</p>
                                  
                                  <p style="font:13px arial;margin:10px"><br>En este correo electronico hemos eliminado las tildes para evitar errores en su visualizacion.<br>Este correo es generado de manera automatica, por favor no responder.</p>
              
                              </td>
                            </tr>
                  </tbody>
                </table>
              </div>
            </html>`,
            attachments:
            [
              {
                filename: `${cpecontent.id}.xml`,
                path: `${cpecontent.urlCpe}`,
                contentType:
                  'application/xml',
              },
              {
                filename: `R-${cpecontent.id}.xml`,
                path: `${cpecontent.urlCdr}`,
                contentType:
                  'application/xml',
              },
              {
                filename: `${cpecontent.id}.pdf`,
                path: `${cpecontent.urlPdf}`,
                contentType:
                  'application/pdf',
              }
            ],
          };

          transporter.sendMail(mail, function(error: any, info: { response: string; }) {
            if (error) {  
              const dataMail = {
                messageId: JSON.stringify(error),
                fechaMail,
                status: 'ERROR'
              }  
              resolve(dataMail);
            } else {
              const dataMail = {
                messageId: info.response,
                fechaMail,
                status: 'SUCCESS'
              } 
              resolve(dataMail);
            }
          }); 
       
      } catch (err) {
        const dataMail = {
            messageId: 'Error en el proceso de enviar correo: ' + err,
            fechaMail,
            status: 'ERROR'
          }
          resolve(dataMail);
      } 

    });
  }
    
} 