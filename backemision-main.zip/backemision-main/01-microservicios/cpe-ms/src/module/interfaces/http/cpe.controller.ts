import { Request, Response } from "express";
import CpeApplication from "../../application/cpe.application";

export default class CpeController {
  constructor(private application: CpeApplication) { 
    this.getCpe = this.getCpe.bind(this); 
    this.searchCpe = this.searchCpe.bind(this); 
    this.getSedes = this.getSedes.bind(this); 

  }
 
  async getCpe(req: Request, res: Response) {  
    const data = await this.application.getCpe(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

  async getResumen(req: Request, res: Response) {  
    const data = await this.application.getResumen(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

  async getTotalEmision(req: Request, res: Response) {   
    const data = await this.application.getTotalEmision(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

  async getTotalEstados(req: Request, res: Response) {  
    const data = await this.application.getTotalEstados(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

  async getEstadosTipoCpe(req: Request, res: Response) {  
    const data = await this.application.getEstadosTipoCpe(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

  async sendEmail(req: Request, res: Response) {  
    const data = await this.application.sendEmail(req.body);   
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

  async searchCpe(req: Request, res: Response) {
    const data = await this.application.searchCpe(req.body);
 
    let cpe:any;
    if (data == null) {
        cpe = {
            "status": false,
            "content": null,
            "message": 'El Comprobante electrónico no existe.'
        }
    }else{

        const dataDep = {
            serieCpe:data.serieCpe,
            numeroCpe:data.numeroCpe,
            codigoRespuesta:data.codigoRespuesta,
            descripcionRespuesta:data.descripcionRespuesta,
            urlCpe:data.urlCpe,
            urlPdf:data.urlPdf,
            urlCdr:data.urlCdr
        }
        
        cpe = {
            "status": true,
            "content": dataDep,
            "message": ''
        }
    } 
    res.json(cpe);
  }

  async getSedes(req: Request, res: Response) {  
    const data = await this.application.getSedes(req.body);  

    let json:any = []

    data.map((d:any) => {
        json.push({"sede": d})
    })
  
    const cpes = {
        "status": true,
        "content": json,
        "message": ''
    } 
    res.json(cpes);
  }

  async getTipoCpe(req: Request, res: Response) {
    const tipoCpe = {
      "status": true,
      "content": [
          {
              "tipocpeId": 1,
              "tipocpeDesc": "Factura",
              "tipocpeCod": "01",
              "estado": true
          },
          {
              "tipocpeId": 2,
              "tipocpeDesc": "Boleta",
              "tipocpeCod": "03",
              "estado": true
          },
          {
              "tipocpeId": 3,
              "tipocpeDesc": "Nota de Débito",
              "tipocpeCod": "08",
              "estado": true
          },
          {
              "tipocpeId": 4,
              "tipocpeDesc": "Nota de Crédito",
              "tipocpeCod": "07",
              "estado": true
          },
          {
              "tipocpeId": 5,
              "tipocpeDesc": "Guía de Remision",
              "tipocpeCod": "09",
              "estado": true
          },
          {
              "tipocpeId": 6,
              "tipocpeDesc": "Retención",
              "tipocpeCod": "20",
              "estado": true
          },
          {
              "tipocpeId": 7,
              "tipocpeDesc": "Percepción",
              "tipocpeCod": "40",
              "estado": true
          }
      ],
        "message": ''
    } 
    res.json(tipoCpe);
  }
  async getTipoDoc(req: Request, res: Response) {
    const tipoDoc = {
      "status": true,
      "content": [
          {
              "tipodocId": 1,
              "tipodocDesc": "DOC.TRIB.NO.DOM.SIN.RUC",
              "tipodocCod": "0",
              "estado": true
          },
          {
              "tipodocId": 2,
              "tipodocDesc": "Documento Nacional de Identidad",
              "tipodocCod": "1",
              "estado": true
          },
          {
              "tipodocId": 3,
              "tipodocDesc": "Carnet de extranjería",
              "tipodocCod": "4",
              "estado": true
          },
          {
              "tipodocId": 4,
              "tipodocDesc": "Registro Unico de Contributentes",
              "tipodocCod": "6",
              "estado": true
          },
          {
              "tipodocId": 5,
              "tipodocDesc": "Pasaporte",
              "tipodocCod": "7",
              "estado": true
          },
          {
              "tipodocId": 6,
              "tipodocDesc": "Permiso Temporal de Permanencia - PTP",
              "tipodocCod": "F",
              "estado": true
          },
          {
              "tipodocId": 7,
              "tipodocDesc": "DOC.IDENT.PAIS.RESIDENCIA-NO.D",
              "tipodocCod": "B",
              "estado": true
          },
          {
              "tipodocId": 8,
              "tipodocDesc": "Tax Identification Number - TIN – Doc Trib PP.NN",
              "tipodocCod": "C",
              "estado": true
          },
          {
              "tipodocId": 9,
              "tipodocDesc": "Identification Number - IN – Doc Trib PP. JJ",
              "tipodocCod": "D",
              "estado": true
          },
          {
              "tipodocId": 10,
              "tipodocDesc": "TAM- Tarjeta Andina de Migración",
              "tipodocCod": "E",
              "estado": true
          }
      ],
      "message": ''
  }
    res.json(tipoDoc);
  }

  async getEstadoCpe(req: Request, res: Response) {
    const estadoCpe = {
      "status": true,
      "content": [
        {
            "estado_id": 1,
            "estado_desc": "RECHAZADO",
            "estado_cod": "99", 
            "estado": 1
        },
        {
            "estado_id": 2,
            "estado_desc": "PENDIENTE",
            "estado_cod": "01", 
            "estado": 1
        },
        {
            "estado_id": 3,
            "estado_desc": "ACEPTADO",
            "estado_cod": "0", 
            "estado": 1
        },
        {
            "estado_id": 4,
            "estado_desc": "ANULADO",
            "estado_cod": "02", 
            "estado": 1
        },
        {
            "estado_id": 5,
            "estado_desc": "BAJA",
            "estado_cod": "03", 
            "estado": 1
        }
    ],
      "message": ''
  }
    res.json(estadoCpe);
  }

  async getResumenCpe(req: Request, res: Response) {  
    const data = await this.application.getResumenCpe(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }
 
}
