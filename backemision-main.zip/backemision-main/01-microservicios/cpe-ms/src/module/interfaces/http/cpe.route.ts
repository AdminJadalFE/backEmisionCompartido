import express, { Request, Response } from "express";
import ValidatorHelper from "../../helpers/validator.helper";

import CpeInfrastructure from "../../infrastructure/cpe.infrastructure";
import CpeApplication from "../../application/cpe.application";
import CpeController from "./cpe.controller";

import ResumenInfrastructure from "../../infrastructure/resumen.infrastructure";
import ResumenApplication from "../../application/resumen.application";
import ResumenController from "./resumen.controller";

import { searchCpe } from "./schema/cpe.searchcpe.schema";
import { getCpe } from "./schema/cpe.getcpe.schema";
import { getResumen } from "./schema/resumen.getresumen.schema";
import EventoInfrastructure from "../../infrastructure/evento.infrastructure";

const cpeInfrastructure = new CpeInfrastructure();
const eventoInfrastructure = new EventoInfrastructure();
const cpeApplication = new CpeApplication(cpeInfrastructure, eventoInfrastructure);
const cpeController = new CpeController(cpeApplication);

const resumenInfrastructure = new ResumenInfrastructure();
const resumenApplication = new ResumenApplication(resumenInfrastructure);
const resumenController = new ResumenController(resumenApplication);

class RouterOrder {
  router: express.Router;

  constructor() {
    this.router = express.Router();
    this.mountRoutes();
  }

  mountRoutes() { 
    this.router.get("/tipocpe", cpeController.getTipoCpe.bind(cpeController));  
    this.router.get("/tipodoc", cpeController.getTipoDoc.bind(cpeController));  
    this.router.get("/estadocpe", cpeController.getEstadoCpe.bind(cpeController));  
    this.router.post("/sedes", cpeController.getSedes.bind(cpeController));  
    this.router.post("/getcpe", ValidatorHelper.validate(getCpe), cpeController.getCpe.bind(cpeController));
    this.router.post("/searchcpe", ValidatorHelper.validate(searchCpe), cpeController.searchCpe.bind(cpeController));   
    this.router.post("/getdataresumen", cpeController.getResumen.bind(cpeController));  
    this.router.post("/gettotalemision", cpeController.getTotalEmision.bind(cpeController));  
    this.router.post("/gettotalestados", cpeController.getTotalEstados.bind(cpeController));  
    this.router.post("/getestadotipocpe", cpeController.getEstadosTipoCpe.bind(cpeController));  
    this.router.post("/sendemail", cpeController.sendEmail.bind(cpeController));  

    this.router.post("/getresumencpe", cpeController.getResumenCpe.bind(cpeController));  

    this.router.post("/getresumen", ValidatorHelper.validate(getResumen), resumenController.getResumen.bind(resumenController));  
  }
}

export default new RouterOrder().router;
