import Joi from 'joi';

export const searchCpe = Joi.object({
    rucEmisor: Joi.string().required(), 
    tipoDocReceptor: Joi.string().required(),
    rucReceptor: Joi.string().required(), 
    tipoCpe: Joi.string().required(), 
    serieCpe: Joi.string().required(), 
    numeroCpe: Joi.string().required(), 
    fechaCpe: Joi.string().required(), 
    totalCpe: Joi.date().required(),  
    })