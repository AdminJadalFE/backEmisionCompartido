import Joi from 'joi';

export const getCpe = Joi.object({
    rucEmisor: Joi.string().required(), 
    fechaDesde: Joi.string().required(), 
    fechaHasta: Joi.string().required(), 
    estadoCpe: Joi.string().required(), 
    serieCpe: Joi.string().required(), 
    numeroDesde: Joi.string().required(), 
    numeroHasta: Joi.string().required(), 
    tipoCpe: Joi.string().required(), 
    rucReceptor: Joi.string().required(), 
    Sucursal: Joi.string().required(), 
    })