import { Request, Response } from "express";
import ResumenApplication from "../../application/resumen.application";

export default class ResumenController {
  constructor(private application: ResumenApplication) { 
    this.getResumen = this.getResumen.bind(this);  
  }
 
  async getResumen(req: Request, res: Response) {  
    const data = await this.application.getResumen(req.body);      
    const cpes = {
        "status": true,
        "content": data ,
        "message": ''
    } 
    res.json(cpes);
  }

}