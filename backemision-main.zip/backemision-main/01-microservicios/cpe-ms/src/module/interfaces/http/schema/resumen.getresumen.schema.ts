import Joi from 'joi';

export const getResumen = Joi.object({
    rucEmisor: Joi.string().required(), 
    fechaDesde: Joi.string().required(), 
    fechaHasta: Joi.string().required(),
    tipoCpe: Joi.string().required(), 
    })