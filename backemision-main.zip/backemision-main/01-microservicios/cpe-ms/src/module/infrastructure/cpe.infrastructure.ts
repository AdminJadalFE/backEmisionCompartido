import CpeRepository from "../domain/repositories/cpe.repository";
import Model from "./models/cpe.model"; 

export default class CpeInfrastructure implements CpeRepository {
  
  async getCpeById(id: string): Promise<any>{ 
    return await Model.findOne({id}); 
  }  

  async getCpe(where: object, select:object): Promise<any>{ 
    return await Model.find(where, select); 
  }  

  async getResumen(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<any>{  
  
    return await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe",
              montoCpe: { $sum: '$totalCpe' },
              totalCpe: { $sum: 1 }
            }
         }
       ]
     ) 
  }  

  async getTotalEmision(where: Object): Promise<any>{   
    const totalCpe = await Model.find(where).count();   
    return totalCpe;
  }  

  async getTotalEstados(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<any>{  
  
    return await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$estadoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     ) 
  }  

  async getEstadosTipoCpe(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<any>{  
  
    const cpeTotal =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     )  


     const cpeRechazado =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              estadoCpe:'RECHAZADO',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     ) 

     const cpePendiente =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              estadoCpe:'PENDIENTE',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     )  

     const tipoCpe:any = [];
     const totalCpe:any = [];  
     const pendienteCpe:any = [];  
     const rechazadoCpe:any = [];  

     cpeTotal.map((t) => { 
      tipoCpe.push(t._id); 
      totalCpe.push(t.totalCpe); 
 
      let totPen = 0;
      cpePendiente.map((p) => {  
        if (t._id == p._id) {
          totPen = p.totalCpe 
        } 
      })  
      pendienteCpe.push(totPen); 

      let totRech = 0;
      cpeRechazado.map((r) => { 
        if (t._id == r._id) {
          totRech = r.totalCpe 
        } 
      })  
      rechazadoCpe.push(totRech); 

    })

     const cpes = {
      tipoCpe : tipoCpe,
      totalCpe: totalCpe, 
      rechazadoCpe: rechazadoCpe,
      pendienteCpe: pendienteCpe

     } 
     return cpes;
  }  

  async searchCpe(where: object, select:object): Promise<any>{
    return await Model.findOne(where, select);
  } 

  async getSedes(where: object): Promise<any>{ 
    return await Model.distinct('Sucursal', where);   
  }   
 


  async getResumenCpe(rucEmisor: string, fechaDesde: string, fechaHasta: string): Promise<any>{  
  
    const cpeTotal =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     )  

     const cpeAceptado =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              estadoCpe:'ACEPTADO',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     ) 


     const cpeRechazado =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              estadoCpe:'RECHAZADO',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     ) 

     const cpePendiente =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              estadoCpe:'PENDIENTE',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     )  


     const cpeBaja =  await Model.aggregate(
      [ 
        {
            $match:  {
              estadoProccess: 'SUCCESS',
              estadoCpe:'BAJA',
              rucEmisor: rucEmisor 
            } 
        },
        {
          $match:  { 
            fechaCpe: {
              '$gte': new Date(fechaDesde),
              '$lte': new Date(fechaHasta),
            }
          } 
       },
        {
          $group :
            {
              _id : "$tipoCpe", 
              totalCpe: { $sum: 1 }
            }
         }
       ]
     )  

     const tipoCpe:any = [];
     const totalCpe:any = [];  
     const aceptadoCpe:any = [];  
     const pendienteCpe:any = [];  
     const rechazadoCpe:any = [];  
     const bajaCpe:any = [];  

     cpeTotal.map((t) => { 
      tipoCpe.push(t._id); 
      totalCpe.push(t.totalCpe); 
 
      let totPen = 0;
      cpePendiente.map((p) => {  
        if (t._id == p._id) {
          totPen = p.totalCpe 
        } 
      })  
      pendienteCpe.push(totPen); 

      let totAce = 0;
      cpeAceptado.map((p) => {  
        if (t._id == p._id) {
          totAce = p.totalCpe 
        } 
      })  
      aceptadoCpe.push(totAce); 

      let totRech = 0;
      cpeRechazado.map((r) => { 
        if (t._id == r._id) {
          totRech = r.totalCpe 
        } 
      })  
      rechazadoCpe.push(totRech); 

      let totBaja = 0;
      cpeBaja.map((r) => { 
        if (t._id == r._id) {
          totBaja = r.totalCpe 
        } 
      })  
      bajaCpe.push(totBaja); 

    })

     const cpes = {
      tipoCpe : tipoCpe,
      totalCpe: totalCpe, 
      aceptadoCpe: aceptadoCpe,
      rechazadoCpe: rechazadoCpe,
      pendienteCpe: pendienteCpe,
      bajaCpe: bajaCpe, 
     } 
     
     return cpes;
  }  


}
