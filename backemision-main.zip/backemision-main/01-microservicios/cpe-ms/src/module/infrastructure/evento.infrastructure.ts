import Model from "./models/evento.model";
import { EventoEntity } from '../domain/entities/evento.entity';
import EventoRepository from "../domain/repositories/evento.repository";

export default class EventoInfrastructure implements EventoRepository {
   
  async registerEvent(evento: EventoEntity): Promise<any>{  
    await Model.create(evento);
    return evento;  
  }  


}
