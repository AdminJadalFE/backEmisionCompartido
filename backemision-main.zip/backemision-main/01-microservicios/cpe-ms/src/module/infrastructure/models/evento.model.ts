import mongoose from "mongoose";

class EventoModel {

    private eventoSchema: mongoose.Schema;

    constructor() {
        this.eventoSchema = new mongoose.Schema({
            tipo:{
                type: String,
                required: true
            }, 
            id:{
                type: String,
                required: true
            }, 
            referencia:{
                type: String,
                required: true
            },  
            estado:{
                type: String,
                required: true
            },  
            detalleEvento:{
                type: String,
                required: true
            },  
            fechaHora:{
                type: Date,
                required: true
            }

        });
    }

    get model(): mongoose.Model<mongoose.Document> {
        return mongoose.model<mongoose.Document>("Evento", this.eventoSchema);
    }
 
}

export default new EventoModel().model;