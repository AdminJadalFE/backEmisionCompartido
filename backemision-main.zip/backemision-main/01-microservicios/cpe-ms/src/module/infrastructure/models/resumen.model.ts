import mongoose from "mongoose";

class ResumenModel {

    private resumenSchema: mongoose.Schema;

    constructor() {
        this.resumenSchema = new mongoose.Schema({
            id:{
                type: String,
                required: true
            }, 
            fechaPublicacion:{
                type: Date,
                required: true
            },
            fechaResumen:{
                type: Date,
                required: true
            },
            fechaReferencia:{
                type: Date,
                required: true
            }, 
            rucEmisor:{
                type: String,
                required: true
            },  
            tipoCpe:{
                type: String,
                required: true
            },
            serieCpe:{
                type: String,
                required: true
            },
            numeroCpe:{
                type: String,
                required: true
            }, 
            urlCpe:{
                type: String,
                required: true
            },
            urlPdf:{
                type: String,
                required: true
            },
            ticketResumen:{
                type: String 
            },  
            estadoResumen:{
                type: String 
            },
            urlCdr:{
                type: String 
            },
            fechaCdr:{
                type: String 
            },
            horaCdr:{
                type: String 
            },
            codigoRespuesta:{
                type: String 
            },
            descripcionRespuesta:{
                type: String 
            },
            estadoProccess:{
                type: String
            }
        });
    }

    get model(): mongoose.Model<mongoose.Document> {
        return mongoose.model<mongoose.Document>("Resumen", this.resumenSchema);
    }
 
}

export default new ResumenModel().model;