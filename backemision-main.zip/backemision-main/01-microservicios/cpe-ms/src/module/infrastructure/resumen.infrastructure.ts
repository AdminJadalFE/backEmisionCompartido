import ResumenRepository from "../domain/repositories/resumen.repository";
import Model from "./models/resumen.model";

export default class ResumenInfrastructure implements ResumenRepository {
 
  async getResumen(where: object, select:object): Promise<any>{ 
    const cpes = await Model.find(where, select);
    return cpes;
  }  
 
}
