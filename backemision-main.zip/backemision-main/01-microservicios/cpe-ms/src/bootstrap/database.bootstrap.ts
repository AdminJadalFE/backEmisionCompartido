import mongoose from "mongoose";
import { Bootstrap } from "./bootstrap";

export default class DatabaseBootstrap extends Bootstrap {
  initialize(): Promise<boolean | Error> {
    return new Promise((resolve, reject) => {
      const username = process.env.MONGO_USERNAME || "jadalfe";
      const password = process.env.MONGO_PASSWORD || "MyKjeK0wkPLc8v1r";
      const host = process.env.MONGO_HOST || "bdjadalfetest.s58enmp.mongodb.net"; 
      const database = process.env.MONGO_DATABASE || "processcpe";
      const authSource = process.env.MONGO_AUTH_SOURCE || "admin";
 
  
      const connectionString = `mongodb+srv://${username}:${password}@${host}/${database}?authSource=${authSource}&retryWrites=true&w=majority`; 
 
      const options = {
        maxPoolSize: 10,
        minPoolSize: 5,
      };

      const cb = (error: Error) => {
        if (error) {
          return reject(error);
        }
        console.log("Connected to MongoDB");
        resolve(true);
      };

      mongoose.connect(connectionString, options, cb);
    });
  }
}
