import express, { Application, Request, Response } from "express"; 

import Router from "./module/interfaces/http/cpe.route";
class App {
  expressApp: Application;

  constructor() {
    this.expressApp = express();
    this.habilitarCORS();
    this.middlewares();
    this.mountRoutes();
  }

  middlewares() {
    this.expressApp.use(express.json());
    this.expressApp.use(express.urlencoded({ extended: false }));
  }

  mountRoutes() {
    this.expressApp.use("/cpe", Router);

    this.expressApp.get("/", (req: Request, res: Response) => {
      res.send("Jadal System API!");
    });
  }

  habilitarCORS(){
    this.expressApp.use((req, res, next)=>{
        res.header("Access-Control-Allow-Origin", "*")
        res.header("Access-Control-Allow-Headers", "*")
        res.header("Access-Control-Allow-Methods", "GET, POST"); 
        next();
    });
  } 

  
}

export default new App().expressApp;
