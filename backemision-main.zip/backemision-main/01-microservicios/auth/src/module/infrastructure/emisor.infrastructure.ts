import { EmisorEntity } from "../domain/entities/emisor.entity";
import Repository from "../domain/repositories/emisor.repository";
import Model from "./models/emisor.model";

export default class EmisorInfrastructure implements Repository {
 
  async getOne(where: object): Promise<EmisorEntity>{
    return await Model.findOne(where);
  } 

  async insert(auth: EmisorEntity): Promise<void> {
    await Model.create(auth);
  }

  async update(refreshToken: string, newRefreshToken: string) {
    await Model.updateOne({ refreshToken }, { refreshToken: newRefreshToken });
  }

  async updateUltimaConexion(rucEmisor: string, ultimaConexion: Date): Promise<void> {
    await Model.updateOne({ rucEmisor }, { ultimaConexion});
  }
 
}
