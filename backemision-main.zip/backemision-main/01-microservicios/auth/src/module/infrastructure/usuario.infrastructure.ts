import { UsuarioEntity } from "../domain/entities/usuario.entity";
import Repository from "../domain/repositories/usuario.repository";
import Model from "./models/usuario.model";

export default class UsuarioInfrastructure implements Repository {

 
  async getOne(where: object): Promise<UsuarioEntity>{
    return await Model.findOne(where);
  } 

  async insert(auth: UsuarioEntity): Promise<void> {
    await Model.create(auth);
  }

  async update(refreshToken: string, newRefreshToken: string) {
    await Model.updateOne({ refreshToken }, { refreshToken: newRefreshToken });
  }
 
  async delete(emailUsuario: string): Promise<void> {
    await Model.deleteOne({ emailUsuario });
  }
 
}
