import mongoose from "mongoose";

class EmisorModel {
  private emisorSchema: mongoose.Schema;
 
  constructor() {
    this.emisorSchema = new mongoose.Schema({
      rucEmisor: {
        type: String,
        required: true,
        unique: true,
        trim: true,
      },
      razonSocial: {
        type: String,
        required: true,
        trim: true,
      },
      usuarioSunat: {
        type: String,
        required: true,
        trim: true,
      }, 
      claveSunat: {
        type: String,
        required: true,
        trim: true,
      },
      claveEmisor: {
        type: String,
        required: true,
        trim: true,
      },  
      refreshToken: {
        type: String,
        required: true,
      }, 
      validador: {
        type: String,
        required: true,
      }, 
      ultimaConexion: {
        type: Date
      },
    });
  }

  get model(): mongoose.Model<mongoose.Document> {
    return mongoose.model("Emisor", this.emisorSchema);
  }
}

export default new EmisorModel().model;
