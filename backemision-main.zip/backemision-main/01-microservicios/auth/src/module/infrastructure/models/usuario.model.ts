import mongoose from "mongoose";

class UsuarioModel {
  private usuarioSchema: mongoose.Schema;
 
  constructor() {
    this.usuarioSchema = new mongoose.Schema({
      emailUsuario: {
        type: String,
        required: true,
        unique: true,
        trim: true,
      },
      nombreUsuario: {
        type: String,
        required: true,
        trim: true,
      },
      claveUsuario: {
        type: String,
        required: true,
        trim: true,
      }, 
      refreshToken: {
        type: String,
        required: true,
      },  
    });
  }

  get model(): mongoose.Model<mongoose.Document> {
    return mongoose.model("Usuario", this.usuarioSchema);
  }
}

export default new UsuarioModel().model;
