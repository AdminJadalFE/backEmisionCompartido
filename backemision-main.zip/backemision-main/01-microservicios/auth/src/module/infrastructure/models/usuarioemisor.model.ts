import mongoose from "mongoose";

class usuarioemisorEmisorModel {
  private usuarioemisorSchema: mongoose.Schema;
 
  constructor() {
    this.usuarioemisorSchema = new mongoose.Schema({
      emailUsuario: {
        type: String,
        required: true, 
        trim: true,
      },
      rucEmisor: {
        type: String,
        required: true,
        trim: true,
      },
      razonSocial: {
        type: String,
        required: true,
        trim: true,
      },  
    });
  }

  get model(): mongoose.Model<mongoose.Document> {
    return mongoose.model("UsuarioEmisor", this.usuarioemisorSchema);
  }
}

export default new usuarioemisorEmisorModel().model;
