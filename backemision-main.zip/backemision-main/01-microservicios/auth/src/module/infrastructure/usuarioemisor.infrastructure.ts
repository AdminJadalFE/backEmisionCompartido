import { UsuarioEmisorEntity } from "../domain/entities/usuarioemisor.entity";
import Repository from "../domain/repositories/usuarioemisor.repository";
import Model from "./models/usuarioemisor.model";

export default class UsuarioEmisorInfrastructure implements Repository {

 
  async getOne(where: object): Promise<UsuarioEmisorEntity>{
    return await Model.findOne(where);
  } 

  async getEmisorByUser(where: object): Promise<any>{ 
    return await Model.find(where);  
  }  

  async insert(auth: UsuarioEmisorEntity): Promise<void> {
    await Model.create(auth);
  }
 
  async delete(where: string): Promise<void> {
    await Model.deleteOne({ where });
  }
 
}
