export class UsuarioEmisorRequestBuilder {
  emailUsuario: string;
  nombreUsuario: string;
  claveUsuario: string;
  refreshToken: string; 
  rucEmisor: string; 
  razonSocial: string;

  addemailUsuario(emailUsuario: string): UsuarioEmisorRequestBuilder {
    this.emailUsuario = emailUsuario;
    return this;
  }

  addnombreUsuario(nombreUsuario: string): UsuarioEmisorRequestBuilder {
    this.nombreUsuario = nombreUsuario;
    return this;
  }

  addclaveUsuario(claveUsuario: string): UsuarioEmisorRequestBuilder {
    this.claveUsuario = claveUsuario;
    return this;
  }

  addrefreshToken(refreshToken: string): UsuarioEmisorRequestBuilder {
    this.refreshToken = refreshToken;
    return this;
  }

  addrucEmisor(rucEmisor: string): UsuarioEmisorRequestBuilder {
    this.rucEmisor = rucEmisor;
    return this;
  }

  addrazonSocial(razonSocial: string): UsuarioEmisorRequestBuilder {
    this.razonSocial = razonSocial;
    return this;
  }
 
  build(): UsuarioEmisorRequestEntity {
    return new UsuarioEmisorRequestEntity(this);
  }
}

export class UsuarioEmisorRequestEntity {
  emailUsuario: string;
  nombreUsuario: string;
  claveUsuario: string;
  refreshToken: string; 
  rucEmisor: string; 
  razonSocial: string;

  constructor(builder: UsuarioEmisorRequestBuilder) {
    Object.assign(this, builder);
  }
}
