export class UsuarioBuilder {
  emailUsuario: string;
  nombreUsuario: string;
  claveUsuario: string;
  refreshToken: string; 

  addemailUsuario(emailUsuario: string): UsuarioBuilder {
    this.emailUsuario = emailUsuario;
    return this;
  }

  addnombreUsuario(nombreUsuario: string): UsuarioBuilder {
    this.nombreUsuario = nombreUsuario;
    return this;
  }

  addclaveUsuario(claveUsuario: string): UsuarioBuilder {
    this.claveUsuario = claveUsuario;
    return this;
  }

  addrefreshToken(refreshToken: string): UsuarioBuilder {
    this.refreshToken = refreshToken;
    return this;
  }
  build(): UsuarioEntity {
    return new UsuarioEntity(this);
  }
}

export class UsuarioEntity {
  emailUsuario: string;
  nombreUsuario: string;
  claveUsuario: string;
  refreshToken: string; 

  constructor(builder: UsuarioBuilder) {
    Object.assign(this, builder);
  }
}
