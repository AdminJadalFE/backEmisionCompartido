export class UsuarioEmisorBuilder {
  emailUsuario: string;
  rucEmisor: string; 
  razonSocial: string;

  addemailUsuario(emailUsuario: string): UsuarioEmisorBuilder {
    this.emailUsuario = emailUsuario;
    return this;
  }

  addrucEmisor(rucEmisor: string): UsuarioEmisorBuilder {
    this.rucEmisor = rucEmisor;
    return this;
  }

  addrazonSocial(razonSocial: string): UsuarioEmisorBuilder {
    this.razonSocial = razonSocial;
    return this;
  }
 
  build(): UsuarioEmisorEntity {
    return new UsuarioEmisorEntity(this);
  }
}

export class UsuarioEmisorEntity {
  emailUsuario: string;
  rucEmisor: string; 
  razonSocial: string;

  constructor(builder: UsuarioEmisorBuilder) {
    Object.assign(this, builder);
  }
}
