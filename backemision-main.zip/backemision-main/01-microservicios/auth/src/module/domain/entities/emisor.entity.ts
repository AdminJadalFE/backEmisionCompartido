export class EmisorBuilder {
  rucEmisor: string;
  razonSocial: string;
  usuarioSunat: string;
  claveSunat: string;
  claveEmisor: string;
  refreshToken: string;
  validador: string;
  ultimaConexion: Date;

  addrucEmisor(rucEmisor: string): EmisorBuilder {
    this.rucEmisor = rucEmisor;
    return this;
  }

  addrazonSocial(razonSocial: string): EmisorBuilder {
    this.razonSocial = razonSocial;
    return this;
  }

  addusuarioSunat(usuarioSunat: string): EmisorBuilder {
    this.usuarioSunat = usuarioSunat;
    return this;
  }

  addclaveSunat(claveSunat: string): EmisorBuilder {
    this.claveSunat = claveSunat;
    return this;
  }

  addclaveEmisor(claveEmisor: string): EmisorBuilder {
    this.claveEmisor = claveEmisor;
    return this;
  }

  addRefreshToken(refreshToken: string): EmisorBuilder {
    this.refreshToken = refreshToken;
    return this;
  } 
  addvalidador(validador: string): EmisorBuilder {
    this.refreshToken = validador;
    return this;
  }
  addultimaConexion(ultimaConexion: Date): EmisorBuilder {
    this.ultimaConexion = ultimaConexion;
    return this;
  }
  build(): EmisorEntity {
    return new EmisorEntity(this);
  }
}

export class EmisorEntity {
  rucEmisor: string;
  razonSocial: string;
  usuarioSunat: string;
  claveSunat: string;
  claveEmisor: string;
  refreshToken: string;
  validador: string;
  ultimaConexion: Date;

  constructor(builder: EmisorBuilder) {
    Object.assign(this, builder);
  }
}
