import { UsuarioEmisorEntity } from '../entities/usuarioemisor.entity';

export interface Tokens {
  status: boolean;
  message: string;
  content: string; 
}

export default interface RepositoryUsuarioEmisor {
  getOne(where: Object): Promise<UsuarioEmisorEntity>;
  getEmisorByUser(where: Object): Promise<UsuarioEmisorEntity>; 
  insert(auth: UsuarioEmisorEntity): Promise<void>;
  delete(where: Object): Promise<void>; 
}
