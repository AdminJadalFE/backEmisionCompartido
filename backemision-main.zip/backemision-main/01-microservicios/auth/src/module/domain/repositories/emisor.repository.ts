import { EmisorEntity } from '../entities/emisor.entity';

export interface Tokens {
  status: boolean;
  message: string;
  accessToken: string;
  refreshToken: string;
}

export default interface RepositoryEmisor {
  getOne(where: Object): Promise<EmisorEntity>;
  insert(auth: EmisorEntity): Promise<void>;
  update(refreshToken: string, newRefreshToken: string): Promise<void>;
  updateUltimaConexion(rucEmisor: string, ultimaConexion: Date): Promise<void>;
}
