import { UsuarioEntity } from '../entities/usuario.entity';

export interface Tokens {
  status: boolean;
  message: string;
  email: string;
  nombre: string;
  accessToken: string;
  refreshToken: string;
}

export default interface RepositoryUsuario {
  getOne(where: Object): Promise<UsuarioEntity>;
  insert(auth: UsuarioEntity): Promise<void>;
  delete(where: Object): Promise<void>;
  update(refreshToken: string, newRefreshToken: string): Promise<void>;
}
