import { Request, Response } from "express";
import UsuarioEmisorApplication from "../../application/usuarioemisor.application";

export default class UsuarioEmisorController {
  constructor(private application: UsuarioEmisorApplication) {
    this.delete = this.delete.bind(this); 
    this.getEmisorByUser = this.getEmisorByUser.bind(this); 
  }
 
  async delete(req: Request, res: Response) {
    const { emailUsuario, claveUsuario } = req.body;
    const tokens = await this.application.delete(emailUsuario, claveUsuario);
    res.json(tokens);
  }

  async getEmisorByUser(req: Request, res: Response) {
    const { emailUsuario } = req.body;
    const usuario = await this.application.getEmisorByUser(emailUsuario);
    res.json(usuario);
  }
  
}
