import express, { Request, Response } from "express";
import EmisorApplication from "../../application/emisor.application";

import EmisorInfrastructure from "../../infrastructure/emisor.infrastructure";
import UsuarioInfrastructure from "../../infrastructure/usuario.infrastructure";
import EmisorController from "./emisor.controller";

import ValidatorHelper from "../../helpers/validator.helper";
import UsuarioApplication from '../../application/usuario.application';
import UsuarioController from './usuario.controller';
import UsuarioEmisorInfrastructure from '../../infrastructure/usuarioemisor.infrastructure';
import UsuarioEmisorController from "./usuarioemisor.controller";
import UsuarioEmisorApplication from '../../application/usuarioemisor.application';

const infrastructureEmisor = new EmisorInfrastructure();
const applicationEmisor = new EmisorApplication(infrastructureEmisor);
const controllerEmisor = new EmisorController(applicationEmisor);

const infrastructureUsuario = new UsuarioInfrastructure();
const infrastructureUsuarioEmisor  = new UsuarioEmisorInfrastructure();
const applicationUsuario = new UsuarioApplication(infrastructureUsuario, infrastructureUsuarioEmisor);
const controllerUsuario = new UsuarioController(applicationUsuario);
 
const applicationUsuarioEmisor = new UsuarioEmisorApplication(infrastructureUsuarioEmisor)
const controllerUsuarioEmisor = new UsuarioEmisorController(applicationUsuarioEmisor);

class RouterOrder {
  router: express.Router;

  constructor() {
    this.router = express.Router();
    this.mountRoutes();
  }

  mountRoutes() {
    this.router.post("/register", controllerEmisor.register); 
    this.router.post("/login", controllerEmisor.login); 
    this.router.post("/get-user-sunat", controllerEmisor.getUserSunat); 
    this.router.post("/get-new-access-token", controllerEmisor.getNewAccessToken); 
    this.router.post("/validate-access-token", controllerEmisor.validateAccessToken);

    this.router.post("/user/register", controllerUsuario.register); 
    this.router.post("/user/login", controllerUsuario.login); 
    this.router.post("/user/getuser", controllerUsuario.getUsuario); 
    this.router.post("/user/get-new-access-token", controllerUsuario.getNewAccessToken); 
    this.router.post("/user/validate-access-token", controllerUsuario.validateAccessToken);

    this.router.delete("/useremisor/delete", controllerUsuarioEmisor.delete);
    this.router.post("/useremisor/getemisorbyuser", controllerUsuarioEmisor.getEmisorByUser);

  }
}

export default new RouterOrder().router;
