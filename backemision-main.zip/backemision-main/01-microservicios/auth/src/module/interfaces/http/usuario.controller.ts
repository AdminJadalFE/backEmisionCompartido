import { Request, Response } from "express";
import UsuarioApplication from "../../application/usuario.application";

export default class UsuarioController {
  constructor(private application: UsuarioApplication) {
    this.register = this.register.bind(this);
    this.login = this.login.bind(this);
    this.getUsuario = this.getUsuario.bind(this);
    this.getNewAccessToken = this.getNewAccessToken.bind(this);
    this.validateAccessToken = this.validateAccessToken.bind(this);
  }

  async register(req: Request, res: Response) {
    const usuario = req.body;
    const result = this.application.register(usuario);
    res.sendStatus(200);
  }

  async login(req: Request, res: Response) {
    const { emailUsuario, claveUsuario } = req.body;
    const tokens = await this.application.login(emailUsuario, claveUsuario);
    res.json(tokens);
  }

  async getUsuario(req: Request, res: Response) {
    const { emailUsuario } = req.body;
    const usuario = await this.application.getUsuario(emailUsuario);
    res.json(usuario);
  }
 
  async getNewAccessToken(req: Request, res: Response) {
    const { refreshToken } = req.body;
    const tokens = await this.application.getNewAccessToken(refreshToken);
    res.json(tokens);
  }

  async validateAccessToken(req: Request, res: Response) {
    const { accessToken } = req.body;
    const isValid = await this.application.validateAccessToken(accessToken);
    res.json({ isValid });
  }
}
