import { UsuarioEmisorRequestEntity } from '../domain/entities/usuarioemisorrequest.entity';
import { UsuarioBuilder } from "../domain/entities/usuario.entity";
import { UsuarioEmisorBuilder } from "../domain/entities/usuarioemisor.entity";
import RepositoryUsuario, { Tokens } from "../domain/repositories/usuario.repository";
import RepositoryUsuarioEmisor from '../domain/repositories/usuarioemisor.repository';
import { UsuarioService } from "./usuario.service";

import * as bcrypt from "bcryptjs";
 
const usuarioService = new UsuarioService();

export default class UsuarioApplication {
  private repositoryUsuario: RepositoryUsuario;
  private repositoryUsuarioEmisor: RepositoryUsuarioEmisor;

  constructor(repositoryUsuario: RepositoryUsuario, repositoryUsuarioEmisor: RepositoryUsuarioEmisor) {
    this.repositoryUsuario = repositoryUsuario;
    this.repositoryUsuarioEmisor = repositoryUsuarioEmisor;
  }

  async register(usuarioemisorRequest: UsuarioEmisorRequestEntity): Promise<any> {
 
    const emailUsuario = usuarioemisorRequest.emailUsuario;
    const usuarioVal = await this.repositoryUsuario.getOne({emailUsuario});

    try {

      if(!usuarioVal){ 
        const claveUsuario = await bcrypt.hash(usuarioemisorRequest.claveUsuario, 10);
        const refreshToken = usuarioService.generateRefreshToken();
        const usuario = new UsuarioBuilder() 
        .addemailUsuario(usuarioemisorRequest.emailUsuario)
        .addnombreUsuario(usuarioemisorRequest.nombreUsuario)
        .addclaveUsuario(claveUsuario) 
        .addrefreshToken(refreshToken)
        .build();   
        await this.repositoryUsuario.insert(usuario); 
      }
 
      const usuarioemisor = new UsuarioEmisorBuilder()  
      .addemailUsuario(usuarioemisorRequest.emailUsuario)
      .addrucEmisor(usuarioemisorRequest.rucEmisor)
      .addrazonSocial(usuarioemisorRequest.razonSocial)
      .build();   
      await this.repositoryUsuarioEmisor.insert(usuarioemisor)

      return{
        status: true,
        message: ""
      } 
      
    } catch (error) {
      console.log(error)
      return{
        status: false,
        message: error
      } 
      
    } 

  }

  async login(emailUsuario: string, claveUsuario: string): Promise<Partial<Tokens>> {

    const usuario = await this.repositoryUsuario.getOne({emailUsuario});

    if(!usuario){
      console.log("Usuario not found");
      return{
        status: false,
        message: "Usuario not found",
        accessToken: null,
        refreshToken: null
      } 
    }
    
    const isMatch = await bcrypt.compare(claveUsuario, usuario.claveUsuario);
    
    if(!isMatch){
      console.log("Password Incorrect");
      return{
        status: false,
        message: "Password Incorrect",
        accessToken: null,
        refreshToken: null
      } 
    } 
      
    return{
      status: true,
      message: null,
      email: usuario.emailUsuario,
      nombre: usuario.nombreUsuario,
      accessToken: usuarioService.generateAccessToken(usuario.emailUsuario),
      refreshToken: usuario.refreshToken
    } 
  }

  async getUsuario(emailUsuario: string): Promise<any> {  
    const emisor = await this.repositoryUsuario.getOne({emailUsuario}); 
    return{
      status: true,
      message: "",
      content: emisor
    }  
  }

  async getNewAccessToken(refreshToken: string): Promise<Partial<Tokens>> {
    const usuario = await this.repositoryUsuario.getOne({refreshToken});
    
    if(!usuario){
      return{
        status: false,
        message: "Usuario not found",
        accessToken: null,
        refreshToken: null
      } 
    }
    
    const newRefreshToken = usuarioService.generateRefreshToken();
    
    await this.repositoryUsuario.update(refreshToken,newRefreshToken);
    
    return{
      status: true,
      message: null,
      email: usuario.emailUsuario,
      nombre: usuario.nombreUsuario,
      accessToken: usuarioService.generateAccessToken(usuario.emailUsuario),
      refreshToken: newRefreshToken
    } 

  }

 async validateAccessToken(accessToken: string): Promise<boolean> {
  try {
    const emisor = await this.repositoryUsuario.getOne({accessToken});

    if (emisor === null) {
      return false;
    }  

    const decoded = await usuarioService.validateAccessToken(accessToken);
    return true;
  } catch (error) {
    return false;
  }
  
 }
 
}
