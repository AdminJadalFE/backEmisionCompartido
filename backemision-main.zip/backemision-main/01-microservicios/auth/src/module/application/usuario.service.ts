import jwt from "jwt-simple";
import moment from "moment";
import { v4 as uuidv4 } from "uuid";

export class UsuarioService {
  generateAccessToken(emailUsuario: string) {
    const payload = {
      emailUsuario, 
      iat: moment().unix(),
      exp: moment().add(24, "hours").unix(),
    };

    return jwt.encode(
      payload,
      process.env.TOKEN_SECRET || "85b34edf-a256-42c3-a35a-750fcb21e090"
    );
  }

  generateRefreshToken(): string {
    return uuidv4();
  }

  validateAccessToken(accessToken: string): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
        const payload = jwt.decode(
          accessToken,
          process.env.TOKEN_SECRET || "85b34edf-a256-42c3-a35a-750fcb21e090"
        );
        if (payload.exp <= moment().unix()) {
          reject(new Error("Token expired"));
        }
        resolve(payload);
      } catch (err) {
        reject(err);
      }
    });
  }
}
