import RepositoryUsuarioEmisor from '../domain/repositories/usuarioemisor.repository';

export default class UsuarioEmisorApplication { 
  private repositoryUsuarioEmisor: RepositoryUsuarioEmisor;

  constructor(repositoryUsuarioEmisor: RepositoryUsuarioEmisor) {
    this.repositoryUsuarioEmisor = repositoryUsuarioEmisor;
  }
 
  async delete(emailUsuario: string, rucEmisor: string): Promise<any> {  
    try {
      await this.repositoryUsuarioEmisor.delete({emailUsuario, rucEmisor}); 
      return{
        status: true,
        message: "Usuario is deleted"
      }        
    } catch (error) {
      return{
        status: false,
        message: error
      }  
    } 
  }

  async getEmisorByUser(emailUsuario: string): Promise<any> {  
    const emisores = await this.repositoryUsuarioEmisor.getEmisorByUser({emailUsuario}); 
    return{
      status: true,
      message: "",
      content: emisores
    }  
  }
  
 
}
