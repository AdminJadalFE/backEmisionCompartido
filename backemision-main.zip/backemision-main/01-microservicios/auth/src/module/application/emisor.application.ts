import { EmisorEntity } from "../domain/entities/emisor.entity";
import Repository, { Tokens } from "../domain/repositories/emisor.repository";
import * as bcrypt from "bcryptjs";
import { EmisorService } from "./emisor.service";
import {format} from "date-fns"; 

const emisorService = new EmisorService();

export default class EmisorApplication {
  private repositoryEmisor: Repository;

  constructor(repository: Repository) {
    this.repositoryEmisor = repository;
  }

  async register(auth: EmisorEntity): Promise<void> {
    auth.claveEmisor = await bcrypt.hash(auth.claveEmisor, 10);
    auth.refreshToken = emisorService.generateRefreshToken();
    return await this.repositoryEmisor.insert(auth);
  }

  async login(rucEmisor: string, claveEmisor: string): Promise<Tokens> {

    const emisor = await this.repositoryEmisor.getOne({rucEmisor});

    if(!emisor){
      console.log("Emisor not found");
      return{
        status: false,
        message: "Emisor not found",
        accessToken: null,
        refreshToken: null
      } 
    }
    
    const isMatch = await bcrypt.compare(claveEmisor, emisor.claveEmisor);
    
    if(!isMatch){
      console.log("Password Incorrect");
      return{
        status: false,
        message: "Password Incorrect",
        accessToken: null,
        refreshToken: null
      } 
    } 
    
    const ultimaConexion:Date = new Date(format(new Date(), "yyyy-MM-dd hh:mm:ss"));
    await this.repositoryEmisor.updateUltimaConexion(rucEmisor,ultimaConexion);

    return{
      status: true,
      message: null,
      accessToken: emisorService.generateAccessToken(emisor.rucEmisor),
      refreshToken: emisor.refreshToken
    } 
  }

  async getUserSunat(rucEmisor: string): Promise<Partial<EmisorEntity>> {

    const emisor = await this.repositoryEmisor.getOne({rucEmisor});

    if(!emisor){
      throw new Error("Emisor not found");
    }
      
    return{
      rucEmisor: emisor.rucEmisor,
      usuarioSunat: emisor.usuarioSunat,
      claveSunat: emisor.claveSunat,
      validador: emisor.validador
    } 
  }

  async getNewAccessToken(refreshToken: string): Promise<Tokens> { 
    const emisor = await this.repositoryEmisor.getOne({refreshToken});
    
    if(!emisor){
      return{
        status: false,
        message: "Emisor not found",
        accessToken: null,
        refreshToken: null
      } 
    }
    
    const newRefreshToken = emisorService.generateRefreshToken();
    
    await this.repositoryEmisor.update(refreshToken,newRefreshToken);
    
    return{
      status: true,
      message: null,
      accessToken: emisorService.generateAccessToken(emisor.rucEmisor),
      refreshToken: newRefreshToken
    } 

  }

 async validateAccessToken(accessToken: string): Promise<boolean> {
  try {
    const emisor = await this.repositoryEmisor.getOne({accessToken});

    if (emisor === null) {
      return false;
    }  

    const decoded = await emisorService.validateAccessToken(accessToken);
    return true;
  } catch (error) {
    return false;
  }
  
 }
 
}
