import ServerBoostrap from "./boostrap/server.boostrap";
import DatabaseBootstrap from './boostrap/database.bootstrap';
import BrokerBootstrap from './boostrap/broker.bootstrap';
import TaskBootstrap from './boostrap/task.bootstrap';
import CpeApplication from './module/application/cpe.aplication';
import CpeInfraestructure from './module/infraestructure/cpe.infraestructure';
import BrokerInfraestructure from './module/infraestructure/broker.infraestructure';


const server = new ServerBoostrap();
const database = new DatabaseBootstrap();
const broker = new BrokerBootstrap();
const cpeInfraestructure = new CpeInfraestructure();
const brokerInfraestructure = new BrokerInfraestructure(cpeInfraestructure);
const cpeApplication = new CpeApplication(cpeInfraestructure, brokerInfraestructure);
const task = new TaskBootstrap(cpeApplication);

async function start (){ 
    try {
        await server.initialize();
        await database.initialize(); 
        await broker.initialize();
        await task.listenMessage();
    } catch (error) {
        console.log(error);
        process.exit(1);
    }
}

start();