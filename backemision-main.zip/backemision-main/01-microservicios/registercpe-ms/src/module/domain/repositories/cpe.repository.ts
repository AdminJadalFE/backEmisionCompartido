import { ReceiptEntity, STATUS } from '../entities/cpe.entity';
export default interface Repository{
    insert(cpe: ReceiptEntity): Promise <ReceiptEntity>;
    update(id: string, estado: STATUS): Promise<string>;

}