export type STATUS = "ERROR" | "PENDING" | "COMPLETED";

export class ReceiptBuilder { 
    id: string; 
    fechaPublicacion: Date;
    rucEmisor: string;
    fileCpe: string; 
    filePdf: string; 
    estado: STATUS; 

    addid(id: string): ReceiptBuilder{
        this.id = id;
        return this;
    } 
    addfechaPublicacion(fechaPublicacion: Date): ReceiptBuilder{
        this.fechaPublicacion = fechaPublicacion;
        return this;
    }
    addrucEmisor(rucEmisor: string): ReceiptBuilder{
        this.rucEmisor = rucEmisor;
        return this;
    } 
    addfileCpe(fileCpe: string): ReceiptBuilder{
        this.fileCpe = fileCpe;
        return this;
    } 
    addfilePdf(filePdf: string): ReceiptBuilder{
        this.filePdf = filePdf;
        return this;
    } 
    addestado(estado: STATUS): ReceiptBuilder{
        this.estado = estado;
        return this;
    } 
    build(): ReceiptEntity {
        return new ReceiptEntity(this);
    }
}

export class ReceiptEntity {
    rucEmisor: string; 
    id: string;
    fileCpe: string; 
    estado: STATUS;  
    constructor(builder: ReceiptBuilder){
        Object.assign(this, builder)
    }
}