import mongoose from "mongoose";

class ReceiptModel {

    private receiptSchema: mongoose.Schema;

    constructor() {
        this.receiptSchema = new mongoose.Schema({
           id:{
                type: String,
                required: true
            }, 
            fechaPublicacion:{
                type: Date,
                required: true
            },
            rucEmisor:{
                type: String,
                required: true
            },  
            fileCpe:{
                type: String,
                required: true
            },    
            filePdf:{
                type: String,
                required: true
            },   
            estado:{
                type: String,
                required: true
            } 
        });
    }

    get model(): mongoose.Model<mongoose.Document> {
        return mongoose.model<mongoose.Document>("Receipt", this.receiptSchema);
    }
 
}

export default new ReceiptModel().model;