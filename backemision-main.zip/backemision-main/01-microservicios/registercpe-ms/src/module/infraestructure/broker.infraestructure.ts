import RepositoryBroker from '../domain/repositories/cpe-broker-repository';
import BrokerBootstrap from '../../boostrap/broker.bootstrap';  
import CpeInfraestructure from './cpe.infraestructure'; 
import {EXCHANGE_NAME,EXCHANGE_TYPE,QUEUE_NAME,ROUTING_KEY_ERROR,} from "./enums";
 
export default class BrokerInfraestructure implements RepositoryBroker{

    constructor(private cpeInfraestructure: CpeInfraestructure){}

    async send(message: any): Promise<void> {
        const channel = BrokerBootstrap.getChannel(); 
        const queueName = QUEUE_NAME.ORCHESTATOR_EVENT;
        await channel.assertQueue(queueName, {durable: true});
        await channel.sendToQueue(queueName, Buffer.from(JSON.stringify(message)));
    }

    async receive(): Promise<void> {
        const channel = BrokerBootstrap.getChannel();
        const cpeSucess =  this.receiveMessageSuccess(channel, this.consumerSuccess.bind(this));
        const cpeError =  this.receiveMessageError(channel, this.consumerError.bind(this));
        const cpeConfirm =  this.receiveMessageConfirmCustom(EXCHANGE_NAME.CPE_CONFIRMED_EXCHANGE, channel,this.consumerConfirmedCpe.bind(this));
        const resumenConfirm =  this.receiveMessageConfirmCustom(EXCHANGE_NAME.RESUMEN_CONFIRMED_EXCHANGE, channel,this.consumerConfirmedCpe.bind(this));
        await Promise.all([cpeSucess, cpeError, cpeConfirm, resumenConfirm]);
    }
 
    async receiveMessageSuccess(channel: any, callback: (message: any) => void) {  
        const queueName = QUEUE_NAME.CPE_MAIL_EVENT;
        await channel.assertQueue(queueName, { durable: true });

        // Recibir solo un mensaje a la vez
        channel.prefetch(1);
    
        channel.consume(queueName,
          (message: any) => {
            callback(message);
          },
          { noAck: false }
        );
      }

      async receiveMessageError(channel: any, callback: (message: any) => void) { 
        const exchangeName = EXCHANGE_NAME.FAILED_ERROR_EXCHANGE;
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.TOPIC, {
          durable: true,
        }); 
        const routingKey = ROUTING_KEY_ERROR.CPE_CANCELLED;
        const assertQueue = await channel.assertQueue("", { exclusive: true });
        channel.bindQueue(assertQueue.queue, exchangeName, routingKey); 
        channel.consume(assertQueue.queue, (message: any) => callback(message), {
          noAck: true,
        });
      }

      async receiveMessageConfirmCustom(exchangeName: any, channel: any,callback: (message: any) => void) { 
        await channel.assertExchange(exchangeName, EXCHANGE_TYPE.FANOUT, {
          durable: true,
        }); 
        const assertQueue = await channel.assertQueue("", { exclusive: true });
        channel.bindQueue(assertQueue.queue, exchangeName, ""); 
        channel.consume(assertQueue.queue, (message: any) => callback(message), {
          noAck: true,
        });
      }

      async consumerError(message: any) { 
        const messageAsJSON = JSON.parse(message.content.toString());  
        console.log("consumerError", messageAsJSON)
        const estado = "ERROR"; 
        await this.cpeInfraestructure.update(messageAsJSON.payload.id, estado);
      }

      async consumerSuccess(message: any) { 
        const messageAsJSON = JSON.parse(message.content.toString()); 
        const estado = "COMPLETED";  
        await this.cpeInfraestructure.update(messageAsJSON.payload.id, estado);
      }
     
      async consumerConfirmedCpe(message:any){ 
          const messageAsJSON = JSON.parse(message.content.toString()); 
          const estado = "COMPLETED";  
          await this.cpeInfraestructure.update(messageAsJSON.payload.id, estado);
      } 

}