import { ReceiptEntity, STATUS } from '../domain/entities/cpe.entity';
import Repository from '../domain/repositories/cpe.repository';
import Model from './models/cpe.model';


export default class CpeInfraestructure implements Repository{
    
    async insert(cpe: ReceiptEntity): Promise<ReceiptEntity> {
        
        await Model.create(cpe);
        return cpe;
        
    }
    async update(id: string, estado: STATUS): Promise<string> {
        await Model.findOneAndUpdate({id}, {estado}, { upsert: true, sort: { 'fechaPublicacion': -1 } });
        return estado;
    }
    
}