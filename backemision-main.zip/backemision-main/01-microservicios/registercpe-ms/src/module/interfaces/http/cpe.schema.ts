import Joi from 'joi';

export const CPE_INSERT = Joi.object({
        id: Joi.string().required(), 
        rucEmisor: Joi.string().required(),
        fileCpe: Joi.string().required(), 
        filePdf: Joi.string().required(), 
    })