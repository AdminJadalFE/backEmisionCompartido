import express, {Request, Response} from "express";
import CpeApplication from "../../application/cpe.aplication";
import ValidatorHelper from "../../helpers/validator.helper";
import CpeInfraestructure from "../../infraestructure/cpe.infraestructure";
import CpeController from "./cpe.controller";
import { CPE_INSERT } from "./cpe.schema";
import BrokerInfraestructure from '../../infraestructure/broker.infraestructure';

const infraestructure = new CpeInfraestructure();
const infraestructureBroker = new BrokerInfraestructure(infraestructure);
const application = new CpeApplication(infraestructure, infraestructureBroker);
const controller = new CpeController(application);


class RouterCpe {
    router: express.Router;

    constructor(){
        this.router = express.Router();
        this.mountRoutes();
    }

    mountRoutes(){
        this.router.post("/registercpe", ValidatorHelper.validate(CPE_INSERT), controller.insert.bind(controller));
    }
}
 
export default new RouterCpe().router;