import CpeApplication from '../../application/cpe.aplication';
import { ReceiptEntity, ReceiptBuilder } from '../../domain/entities/cpe.entity';
import { Request, Response } from 'express';
import {format} from "date-fns";  
 
export default class CpeController{
    
    constructor(private cpeApplication:CpeApplication){}

    async insert(req:Request, res:Response){

        const {id, rucEmisor, fileCpe, filePdf } = req.body;
 
        const fechaPublicacion:any = format(new Date(), "yyyy-MM-dd hh:mm:ss");
   
        const entity: ReceiptEntity = new ReceiptBuilder()
                .addid(id)
                .addfechaPublicacion(new Date(fechaPublicacion))
                .addrucEmisor(rucEmisor)   
                .addfileCpe(fileCpe)
                .addfilePdf(filePdf)
                .addestado("PENDING")
                .build();

        let resp:any;
        try {
            await this.cpeApplication.create(entity);  
            resp = { 
                status: true,
                id,
                fechaPublicacion,
                message: ''
            }; 
        } catch (error) {

            console.log(error) 
            resp = { 
                status: false,
                id,
                fechaPublicacion,
                message: error
            }; 
        }
        
        res.json(resp);

    }
}