import { ReceiptEntity, STATUS } from '../domain/entities/cpe.entity';
import { TYPE_MESSAGE } from "../infraestructure/enums";
import Repository from '../domain/repositories/cpe.repository';
import RepositoryBroker from '../domain/repositories/cpe-broker-repository';
 
export default class CpeApplication{
    private repositoryCpe: Repository;
    private repositoryBroker: RepositoryBroker;

    constructor(repository: Repository, repositoryBroker: RepositoryBroker){
        this.repositoryCpe = repository
        this.repositoryBroker = repositoryBroker
    } 
    async create(cpe: ReceiptEntity): Promise<ReceiptEntity>{
  
        const result = await this.repositoryCpe.insert(cpe);
  
        this.repositoryBroker.send({
            type: TYPE_MESSAGE.CPE_RECEIPT,
            payload: result,
        });

        return result;

    } 
    async update(id: string, estado: STATUS): Promise<string>{ 
        return this.repositoryCpe.update(id, estado);
    } 

   async receiveMessage(): Promise<void>{
        await this.repositoryBroker.receive();
   }
     
}