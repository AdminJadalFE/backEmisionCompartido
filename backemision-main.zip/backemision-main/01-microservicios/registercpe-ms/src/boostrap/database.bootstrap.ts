import { Boostrap } from "./boostrap";
import mongoose from 'mongoose';

export default class DatabaseBootstrap extends Boostrap{
    initialize(): Promise<boolean | Error> {
        return new Promise((resolve, reject) => {
            const username = process.env.MONGO_USERNAME || "root";
            const password = process.env.MONGO_PASSWORD || "root";
            const host = process.env.MONGO_HOST || "localhost"; 
            const database = process.env.MONGO_DATABASE || "receipt";
            const authSource = process.env.MONGO_AUTH_SOURCE || "admin";

            const connectionString = `mongodb+srv://${username}:${password}@${host}/${database}?authSource=${authSource}&retryWrites=true&w=majority`; 


            const options = {
                maxPoolSize: 10,
                minPoolSize:5
            }

            const cb = (error:Error) =>{
                if(error){
                    return reject(error)
                }

                console.log('Connected to MongoDB')
                resolve(true);
            }

            mongoose.connect(connectionString, options, cb);
 

        })
    }
    
}