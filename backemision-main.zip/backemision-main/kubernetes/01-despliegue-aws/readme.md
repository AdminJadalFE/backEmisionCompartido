# Despliegue en AWS

### Herramientas a instalar

- Chocolatey (Windows)
- Brew (MAC)
- aws-cli (https://awscli.amazonaws.com/AWSCLIV2.msi)
- helm (choco install kubernetes-helm -y)
- eksctl (choco install eksctl -y)

### Configurar un usuario que acceda a AWS

```
aws configure
```

### Crear Cluster EKS

```
eksctl create cluster --name clusterjadalfetest --without-nodegroup --region us-east-1 --zones us-east-1a,us-east-1b
```

### Agregar nodos al cluster

```
eksctl create nodegroup --cluster clusterjadalfetest --name clusterjadalfetest-nodegroup --node-type t3.medium --nodes 1 --nodes-min 1 --nodes-max 2 --asg-access
```

### Crear IAM Provider

```
eksctl utils associate-iam-oidc-provider --cluster clusterjadalfetest --approve
```

### Descargar política para el cluster

```
curl -o iam_policy.json https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.1.2/docs/install/iam_policy.json



* agregar => "ec2:DescribeAvailabilityZones",
```

### Crear la política

```
aws iam create-policy --policy-name AWSLoadBalancerPolicyJadalfetest --policy-document file://iam_policy.json
```

### Crear cuenta ServiceAccount para el cluster

```
eksctl create iamserviceaccount --cluster clusterjadalfetest --namespace=kube-system --name=aws-lb-jadalfetest --attach-policy-arn=arn:aws:iam::329520817223:policy/AWSLoadBalancerPolicyJadalfetest --override-existing-serviceaccounts --approve
```

### Verificar si existe el ingress controller del balanceador

```
kubectl get deploy -n kube-system alb-ingress-controller
```

### Instalar el target group binding

helm repo add eks https://aws.github.io/eks-charts

```
kubectl apply -k "github.com/aws/eks-charts/stable/aws-load-balancer-controller/crds?ref=master"
```

### Actualizar los repositorios de Helm

```
helm repo update
```

### Instalar el ingress controller del balanceador

```
helm upgrade -i aws-load-balancer-controller eks/aws-load-balancer-controller --set clusterName=clusterjadalfetest --set serviceAccount.create=false --set serviceAccount.name=aws-lb-jadalfetest -n kube-system

```

''''
FIX => Kubernetes Helm Error: UPGRADE FAILED: another operation (install/upgrade/rollback) is in progress.
helm ls --namespace kube-system
helm history aws-load-balancer-controller --namespace kube-system
helm rollback aws-load-balancer-controller 1 --namespace kube-system
''''

### Verificar que se haya instalado el ingress controller

```
kubectl get deploy -n kube-system aws-load-balancer-controller
```

### Crear repositorios para las imágenes

- Ir a ECR y crear los repositorios para cada imagen
- Usar las urls de los repositorios para crear un docker-compose-aws.yaml

### Generar las imágenes desde el docker-compose

```
docker compose -f docker-compose-aws.yaml build
```

### Vincular la cuenta de AWS con la cuenta local de Docker

```
docker login -u AWS -p $(aws ecr get-login-password --region us-east-1) 329520817223.dkr.ecr.us-east-1.amazonaws.com
```

### Para subir las imágenes locales a ECR

```
docker compose -f docker-compose-aws.yaml push
```

### Aplicar manifiestos de servicios

kubectl apply -f rabbitmq.yaml

kubectl delete -f rabbitmq.yaml

kubectl apply -f orquestador.yaml -f gateway.yaml -f auth-ms.yaml -f cpe-ms.yaml -f registercpe-ms.yaml -f proccesscpe-ms.yaml -f sendcpe-ms.yaml -f sendmail-ms.yaml -f sendcperesumen-ms.yaml -f getstatus-ms.yaml

kubectl delete -f orquestador.yaml -f gateway.yaml -f auth-ms.yaml -f cpe-ms.yaml -f registercpe-ms.yaml -f proccesscpe-ms.yaml -f sendcpe-ms.yaml -f sendmail-ms.yaml -f sendcperesumen-ms.yaml -f getstatus-ms.yaml

kubectl delete -f auth-ms.yaml

kubectl delete -f -f gateway.yaml -f cpe-ms.yaml

---

kubectl get deploy aws-load-balancer-controller -n kube-system -o yaml | grep -i serviceAccount
kubectl describe sa -n kube-system

# Obtener contextos

kubectl config get-contexts

# Obtener contexto actual

kubectl config current-context

# Cambiar contexto

kubectl config use-context NAME_CONTEXT
